
#include "TCPconnection.h"

#include <QDebug>
#include <QTimer>
#include <QAbstractSocket>
#include "Structdef.h"

TCPconnection::TCPconnection(QObject *parent)
    : QObject(parent),
    socket(new QTcpSocket(this))
{
    // Connection successful
    connect(socket, &QTcpSocket::connected,
            this, &TCPconnection::TCPConnected);

    // Connection lost
    connect(socket, &QTcpSocket::disconnected,
            this, [this]()
            {
                qDebug() << "Disconnected from server";

                // Retry connection after 2 seconds
                QTimer::singleShot(2000, this, [this]()
                                   {
                                       connectToServer();
                                   });
            });

    // Receive server data
    connect(socket, &QTcpSocket::readyRead,
            this, &TCPconnection::readServerData);

    // Socket errors
    connect(socket, &QTcpSocket::errorOccurred,
            this, [this](QAbstractSocket::SocketError error)
            {
                Q_UNUSED(error);

                qDebug() << "Socket error:"
                         << socket->errorString();

                // Retry if connection failed before being established.
                if (socket->state() == QAbstractSocket::UnconnectedState)
                {
                    QTimer::singleShot(2000, this, [this]()
                                       {
                                           connectToServer();
                                       });
                }
            });

    // Initial connection attempt
    connectToServer();
}

void TCPconnection::connectToServer()
{
    // Do not start another attempt if already connecting/connected
    if (socket->state() != QAbstractSocket::UnconnectedState)
        return;

    qDebug() << "Connecting to server:"
             << serverAddress << serverPort;

    socket->connectToHost(serverAddress, serverPort);
}

void TCPconnection::TCPConnected()
{
    qDebug() << "Connected to server";

    if (loginDetailsReady)
    {
        qDebug() << "Sending login credentials";
        loginCredentials();
    }
    else
    {
        qDebug() << "Login details are not ready yet";
    }
}


void TCPconnection::setLoginDetails(
    const QString &username,
    quint8 privilege)
{
    loginUserName = username;
    userPrivilege = privilege;
    loginDetailsReady = true;

    // If already connected, send immediately.
    // Otherwise, TCPConnected() will send after connection.
    if (socket->state() == QAbstractSocket::ConnectedState)
    {
        loginCredentials();
    }
}



void TCPconnection::loginCredentials()
{
    if (!loginDetailsReady ||
        socket->state() != QAbstractSocket::ConnectedState)
    {
        return;
    }

    QByteArray username = loginUserName.toUtf8();

    if (username.isEmpty() || username.size() >= 10)
    {
        qDebug() << "Invalid username length";
        return;
    }

    // Initialize your protocol message
    LogDetailMessage msg{};

    msg.startOfMessage = 0xC9;
    msg.messageType = 0;
    msg.commandCode = 0;
    msg.sequenceNumber = sequenceNumber;
    msg.messageLength = 81; // Set according to your protocol
    msg.userPrivilege = userPrivilege;

    // Copy username; remaining bytes are zero-initialized
    for (qsizetype i = 0; i < username.size(); ++i)
    {
        msg.userName[i] = username.at(i);
    }

    msg.endOfMessage = 0xCF;

    // Serialize protocol fields
    QByteArray data;
    QDataStream out(&data, QIODevice::WriteOnly);

    out.setVersion(QDataStream::Qt_6_5);
    out.setByteOrder(QDataStream::BigEndian);

    out << quint8(msg.startOfMessage);
    out << quint8(msg.messageType);
    out << quint16(msg.commandCode);
    out << quint16(msg.sequenceNumber);
    out << quint16(msg.messageLength);

    out.writeRawData(msg.userName, 10);

    out << quint8(msg.userPrivilege);
    out << quint8(msg.endOfMessage);

    if (out.status() != QDataStream::Ok)
    {
        qDebug() << "Failed to serialize login message";
        return;
    }

    // Send through the socket
    qint64 bytesWritten = socket->write(data);

    if (bytesWritten != data.size())
    {
        qDebug() << "Failed to queue complete login message";
        return;
    }

    qDebug() << "Login message queued:" << data.toHex(' ');
    qDebug() << "Sequence number:" << sequenceNumber;

    ++sequenceNumber;
}

void TCPconnection::writeData(const QByteArray &data)
{
    if (socket->state() != QAbstractSocket::ConnectedState)
    {
        qDebug() << "Cannot send data: socket is disconnected";
        return;
    }

    qint64 bytesWritten = socket->write(data);

    if (bytesWritten != data.size())
    {
        qDebug() << "Failed to queue complete data";
        return;
    }

    qDebug() << "Data queued:" << data.toHex(' ');
}

void TCPconnection::readServerData()
{
    QByteArray data = socket->readAll();

    qDebug() << "Received:" << data.toHex(' ').toUpper();

    // Call your existing processData(data) here.
}