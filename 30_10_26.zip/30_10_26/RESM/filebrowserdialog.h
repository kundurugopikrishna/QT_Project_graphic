
#ifndef FILEBROWSERDIALOG_H
#define FILEBROWSERDIALOG_H

#include <QDialog>
#include <QStringList>
#include "qarraydataops.h"
#include "MyDateEdit.h"
 class QLabel;
class QPushButton;
class QDateEdit;
class QTableWidget;
class QCheckBox;

class FileBrowserDialog : public QDialog
{
    Q_OBJECT

public:
    explicit FileBrowserDialog(QWidget *parent = nullptr);

    // Returns the full paths of selected files
    QStringList selectedFiles() const;

private:
    QString folderPath;

    QLabel *folderLabel;
    QPushButton *browseButton;
    QPushButton *refreshButton;
    QPushButton *openButton;
    QPushButton *cancelButton;

    QDateEdit *fromDateEdit;
    QDateEdit *toDateEdit;

    QTableWidget *fileTable;
    QCheckBox *recursiveCheckBox;

    void chooseFolder();
    void refreshFiles();
    void applyStyle();
};

#endif // FILEBROWSERDIALOG_H
