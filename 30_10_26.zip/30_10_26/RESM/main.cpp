#include "mainwindow.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
qRegisterMetaType<MsgType>("MsgType");
    if (!w.loginpage())
        return 0;
    w.show();
    return QApplication::exec();
}
/*
 * void TCPconnection::TCPConnected()
{
    qDebug() << "Connected to server";
    emit debugMessage("Connected to server", MsgType::Received);

    if (loginDetailsReady)
        loginCredentials();
    else
        emit debugMessage("Login details are not ready yet", MsgType::Warning);
}

// in the disconnected lambda
emit debugMessage("Disconnected from server, retrying in 2s", MsgType::Error);

// in the errorOccurred lambda
emit debugMessage("Socket error: " + socket->errorString(), MsgType::Error);

// in loginCredentials(), after a successful write
emit debugMessage("Login sent: " + QString(data.toHex(' ').toUpper()), MsgType::Sent);

// in writeData()
emit debugMessage("TX: " + QString(data.toHex(' ').toUpper()), MsgType::Sent);

// in readServerData()
emit debugMessage("RX: " + QString(data.toHex(' ').toUpper()), MsgType::Received);

// a custom color example
emit debugMessageColor("Special event", QColor("#CE93D8"));*/