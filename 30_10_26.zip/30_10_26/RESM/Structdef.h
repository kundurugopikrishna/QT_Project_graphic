
#ifndef STRUCTDEF_H
#define STRUCTDEF_H

#include <QtGlobal>
#include <cstdint>
#include <array>
#include "TCPconnection.h"
#include "Structdef.h"


// Structdef.h
#pragma once

enum class MsgType { Info, Sent, Received, Error, Warning };
// Ensure structures use packed layout for protocol messages.
#pragma pack(push, 1)

// --------------------------------------------------
// Log Detail Message
// --------------------------------------------------
struct LogDetailMessage
{
    quint8  startOfMessage = 0xC9;
    quint8  messageType    = 0;
    quint16 commandCode    = 0;
    quint16 sequenceNumber = 0;
    quint16 messageLength  = 0;
    quint8  userPrivilege  = 0;
    char    userName[10]   = {};
    quint8  endOfMessage   = 0xCF;
};

// --------------------------------------------------
// Set Data Message
// --------------------------------------------------
struct SetDataMessage
{
    std::uint8_t  startOfMessage = 0xC9;
    std::uint8_t  messageType    = 0x81;
    std::uint16_t commandCode    = 0x0000;
    std::uint16_t sequenceNo     = 0x0000;
    std::uint16_t messageLength  = 18;

    char          referenceData[10] = {};
    std::uint64_t elapsedSeconds    = 0;

    std::uint8_t   endOfMessage = 0xCF;
};

// --------------------------------------------------
// Health Check Message
// --------------------------------------------------
struct HealthCheckMessage
{
    std::uint8_t  startOfMessage = 0xC9;
    std::uint8_t  messageType    = 0x81;
    std::uint16_t commandCode    = 0x00C5;
    std::uint16_t sequenceNo     = 0x0000;
    std::uint16_t messageLength  = 9;
    std::uint8_t  endOfMessage   = 0xCF;
};

// --------------------------------------------------
// Health Status Message
// --------------------------------------------------
struct HealthStatus
{
    std::uint8_t  startmsg = 0;
    std::uint8_t  msgtype  = 0;
    std::uint16_t cmdcode  = 0;
    std::uint16_t seqno    = 0;
    std::uint16_t msglength = 0;

    std::uint16_t health_states_rfps  = 0;
    std::uint16_t health_states_GPGPU = 0;

    std::uint8_t  efmsg = 0xCF;
};

// --------------------------------------------------
// Process Status Message
// --------------------------------------------------
struct processStatus
{
    std::uint8_t  startmsg = 0;
    std::uint8_t  msgtype  = 0;
    std::uint16_t cmdcode  = 0;
    std::uint16_t seqno    = 0;
    std::uint16_t msglength = 0;

    std::uint8_t currectprocessno = 0;
    std::array<char, 200> Filename = {};

    std::uint32_t ClusterID = 0;
    std::uint8_t  processstatus = 0;
    std::uint8_t  efmsg = 0xCF;
};

// --------------------------------------------------
// Process Completed Message
// --------------------------------------------------
struct processCompleted
{
    std::uint8_t  startmsg = 0;
    std::uint8_t  msgtype  = 0;
    std::uint16_t cmdcode  = 0;
    std::uint16_t seqno    = 0;
    std::uint16_t msglength = 0;

    std::uint16_t lastStagecompleted = 0;
    std::uint16_t outputfile = 0;

    std::uint8_t processstatus = 0;
    std::uint8_t efmsg = 0xCF;
};

// --------------------------------------------------
// Trigger Message
// --------------------------------------------------
struct TriggerMessage
{
    std::uint8_t  startOfMessage = 0xC9;
    std::uint8_t  messageType    = 0x81;
    std::uint16_t commandCode    = 0x00C1;
    std::uint16_t sequenceNo     = 0x0000;
    std::uint16_t messageLength  = 0x0000;

    std::uint8_t  mode = 0;
    std::uint16_t inputFileCount = 0x0000;
    std::uint16_t lastStage      = 0x0000;
    std::uint16_t upcomingstage  = 0x0000;

    std::uint8_t  endOfMessage = 0xCF;
};

// --------------------------------------------------
// Raw File Message
// --------------------------------------------------
struct RawFileMessage
{
    std::uint8_t  startOfMessage = 0xC9;
    std::uint8_t  messageType    = 0x81;
    std::uint16_t commandCode    = 0x00C2;
    std::uint16_t sequenceNo     = 0x0000;
    std::uint16_t messageLength  = 200;

    char missionIdFileName[200] = {};

    std::uint8_t endOfMessage = 0xCF;
};

#pragma pack(pop)

#endif // STRUCTDEF_H
