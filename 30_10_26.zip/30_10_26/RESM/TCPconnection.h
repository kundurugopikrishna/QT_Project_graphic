#ifndef TCPCONNECTION_H
#define TCPCONNECTION_H

#include <QObject>
#include <QTcpSocket>
#include "Structdef.h"
#include <QTimer>
class TCPconnection : public QObject
{
    Q_OBJECT
public:
    explicit TCPconnection(QObject *parent = nullptr);
    void writeData(const QByteArray &data);
    void TCPConnected();
    void setLoginDetails( const QString &username, quint8 privilege);

signals:

private slots:
    void connectToServer();
    void readServerData();
  //  void processData(const QByteArray &data);
    void loginCredentials();

private:
    QTcpSocket *socket;
    QString serverAddress = "192.168.1.4";
    quint16 serverPort = 5000;
    bool loginDetailsReady =false;
    QString loginUserName;
    quint8 userPrivilege = 0;
  //  bool loginDetailsReady = false;
    uint16_t sequenceNumber;
      QTimer *reconnectTimer;
};

#endif // TCPCONNECTION_H
