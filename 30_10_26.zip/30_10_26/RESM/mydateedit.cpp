#include "mydateedit.h"

#include <QCalendarWidget>
#include <QLineEdit>
#include <QEvent>

MyDateEdit::MyDateEdit(QWidget *parent)
    : QDateEdit(parent)
{
    setCalendarPopup(false);                 // we handle the popup ourselves
    setButtonSymbols(QAbstractSpinBox::NoButtons);

    m_calendar = new QCalendarWidget(this);
    m_calendar->setWindowFlags(Qt::Popup);
    m_calendar->setGridVisible(true);

    connect(m_calendar, &QCalendarWidget::clicked, this,
            [this](const QDate &d) {
                setDate(d);                  // emits dateChanged
                m_calendar->hide();
            });

    // Clicks land on the inner line edit, so watch it
    lineEdit()->installEventFilter(this);
}

bool MyDateEdit::eventFilter(QObject *obj, QEvent *event)
{
    if (obj == lineEdit() && event->type() == QEvent::MouseButtonPress) {
        showCalendar();
    }
    return QDateEdit::eventFilter(obj, event);
}

void MyDateEdit::showCalendar()
{
    m_calendar->setSelectedDate(date());
    m_calendar->move(mapToGlobal(QPoint(0, height())));
    m_calendar->show();
}