#pragma once
#include <QDateEdit>

class QCalendarWidget;

class MyDateEdit : public QDateEdit
{
    Q_OBJECT
public:
    explicit MyDateEdit(QWidget *parent = nullptr);

protected:
    bool eventFilter(QObject *obj, QEvent *event) override;

private:
    void showCalendar();
    QCalendarWidget *m_calendar;
};