#include "mainwindow.h"
#include "ui_mainwindow.h"
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , connection(new TCPconnection(this))
{
    ui->setupUi(this);
    initUI();

    qDebug() << "Qt platform:" << QGuiApplication::platformName();

    // Menu actions
    connect(exit_1,      &QAction::triggered, this, &QWidget::close);
    connect(healthcheck, &QAction::triggered, this, &MainWindow::sendHealthCheck);
    connect(setTime,     &QAction::triggered, this, &MainWindow::sendTimeSynchronization);

    // File actions
    connect(exitAction,  &QAction::triggered, this, &QWidget::close);
    connect(openAction,  &QAction::triggered, this, &MainWindow::selectFile);

    // // Profile actions
    // connect(loginAction,       &QAction::triggered, this, &MainWindow::LoginDetails);
    // connect(logoutAction,      &QAction::triggered, this, &MainWindow::LogoutDetails);
    // connect(profileExitAction, &QAction::triggered, this, &QWidget::close);

    // Signals
    connect(this, &MainWindow::fileCount,         this, &MainWindow::Tigger_ESC_filecout);
    connect(this, &MainWindow::fileCopyCompleted, this, &MainWindow::sendMissionFileMessage);
}

MainWindow::~MainWindow()
{
    delete ui;
}

bool MainWindow::loginpage()
{
    QDialog dialog(this);
    loginDialog = &dialog;

    dialog.setWindowTitle("Login Dialog");
    dialog.setFixedSize(350, 200);

    // Username label
    QLabel *label = new QLabel("Username:", &dialog);

    // Username input: default is admin
    lineEdit = new QLineEdit(&dialog);
    lineEdit->setText("admin");
    lineEdit->setMaxLength(10);

    // Radio buttons
    radioButton1 = new QRadioButton("Option 1", &dialog);
    radioButton2 = new QRadioButton("Option 2", &dialog);

    // Select Option 1 by default
    radioButton1->setChecked(true);

    // Make the radio buttons mutually exclusive
    QButtonGroup *radioGroup = new QButtonGroup(&dialog);
    radioGroup->addButton(radioButton1);
    radioGroup->addButton(radioButton2);

    // Login button
    QPushButton *button = new QPushButton("Login", &dialog);

    // Username row
    QHBoxLayout *rowLayout = new QHBoxLayout;
    rowLayout->addWidget(label);
    rowLayout->addWidget(lineEdit);

    // Radio-button row
    QHBoxLayout *radioLayout = new QHBoxLayout;
    radioLayout->addWidget(radioButton1);
    radioLayout->addWidget(radioButton2);

    // Main layout
    QVBoxLayout *mainLayout = new QVBoxLayout(&dialog);
    mainLayout->addLayout(rowLayout);
    mainLayout->addLayout(radioLayout);
    mainLayout->addWidget(button);

    // Connect Login button
    connect(button, &QPushButton::clicked,
            this, &MainWindow::buttoncliked);

    // Wait for login result
    const bool success =
        (dialog.exec() == QDialog::Accepted);

    // Clear pointers to local dialog widgets
    loginDialog = nullptr;
    lineEdit = nullptr;
    radioButton1 = nullptr;
    radioButton2 = nullptr;

    return success;
}

// =========================================================
//  UI
// =========================================================
// void MainWindow::initUI()
// {

//     // ---------- Header ----------
//     QWidget *header = new QWidget(this);
//     header->setFixedHeight(40);
//     header->setStyleSheet("background-color: yellow;");

//     QHBoxLayout *headerLayout = new QHBoxLayout(header);
//     headerLayout->setContentsMargins(0, 0, 10, 0);
//     headerLayout->setSpacing(0);

//     // ---------- Menu bar style ----------
//     const QString barStyle =
//         "QMenuBar { background-color: yellow; color: black; }"
//         "QMenuBar::item {"
//         " background-color: yellow;"
//         " color: black;"
//         " padding: 5px 15px;"
//         "}"
//         "QMenuBar::item:selected { background-color: orange; }";

//     const QString menuStyle =
//         "QMenu {"
//         " background-color: yellow;"
//         " color: black;"
//         " border: 1px solid black;"
//         "}"
//         "QMenu::item {"
//         " background-color: yellow;"
//         " color: black;"
//         " padding: 6px 25px;"
//         "}"
//         "QMenu::item:selected {"
//         " background-color: orange;"
//         " color: black;"
//         "}";

//     // ---------- Menu bar ----------
//     bar = new QMenuBar(header);
//     bar->setNativeMenuBar(false);
//     bar->setStyleSheet(barStyle);
//     bar->setSizePolicy(
//         QSizePolicy::Maximum,
//         QSizePolicy::Fixed
//         );

//     // ---------- Menu ----------
//     menu = bar->addMenu("Menu");
//     menu->setStyleSheet(menuStyle);

//     healthcheck = new QAction("Health", this);
//     setTime = new QAction("SetTime", this);
//     exit_1 = new QAction("Exit", this);

//     menu->addAction(healthcheck);
//     menu->addAction(setTime);
//     menu->addAction(exit_1);

//     // ---------- File ----------
//     fileMenu = bar->addMenu("File");
//     fileMenu->setStyleSheet(menuStyle);

//     newAction = new QAction("New", this);
//     openAction = new QAction("Open", this);
//     exitAction = new QAction("Exit", this);

//     fileMenu->addAction(newAction);
//     fileMenu->addAction(openAction);
//     fileMenu->addAction(exitAction);

//     // ---------- View ----------
//     viewMenu = bar->addMenu("View");
//     viewMenu->setStyleSheet(menuStyle);

//     // IMPORTANT: Add the menu bar to the header layout
//     headerLayout->addWidget(bar);
//     headerLayout->addStretch();


//     // =====================================================
//     //                     SPLITTER
//     // =====================================================
//     QSplitter *splitter = new QSplitter(Qt::Vertical, this);

//     // ---------- Top panel ----------
//     QWidget *topPanel = new QWidget();
//     topPanel->setStyleSheet("background-color: #3498db;");

//     QVBoxLayout *topPanelLayout = new QVBoxLayout(topPanel);
//     topPanelLayout->setContentsMargins(10, 10, 10, 10);
//     topPanelLayout->setSpacing(0);

//     // Debug text area
//     select = new QPlainTextEdit(topPanel);

//     select->setStyleSheet(
//         "QPlainTextEdit {"
//         "    background-color: #0B1F3A;"
//         "    color: #FFFFFF;"
//         "    border: 1px solid #42A5F5;"
//         "    selection-background-color: #42A5F5;"
//         "    selection-color: #FFFFFF;"
//         "}"
//         );

//     select->setReadOnly(true);

//     // Allow the text area to expand in both directions
//     select->setSizePolicy(
//         QSizePolicy::Expanding,
//         QSizePolicy::Expanding
//         );

//     // Give the text area all available vertical space
//     topPanelLayout->addWidget(select, 1);
//     //topPanelLayout->addStretch();

//     // ---------- Bottom panel ----------
//     QWidget *bottomPanel = new QWidget();
//     bottomPanel->setStyleSheet("background-color: #2ecc71;");

//     QVBoxLayout *bottomPanelLayout = new QVBoxLayout(bottomPanel);
//     bottomPanelLayout->setContentsMargins(0, 0, 0, 0);
//     bottomPanelLayout->setSpacing(0);

//     QWidget *bottomHeader = new QWidget();
//     bottomHeader->setFixedHeight(40);
//     bottomHeader->setStyleSheet("background-color: #27ae60;");

//     bottomPanelLayout->addWidget(bottomHeader);
//     bottomPanelLayout->addStretch();

//     splitter->addWidget(topPanel);
//     splitter->addWidget(bottomPanel);
//     splitter->setSizes({300, 300});
//     splitter->setChildrenCollapsible(false);

//     // =====================================================
//     //               MAIN WINDOW LAYOUT
//     // =====================================================
//     QWidget *centralWidget = new QWidget(this);
//     QVBoxLayout *mainLayout = new QVBoxLayout(centralWidget);
//     mainLayout->setContentsMargins(0, 0, 0, 0);
//     mainLayout->setSpacing(0);

//     mainLayout->addWidget(header);
//     mainLayout->addWidget(splitter);

//     setCentralWidget(centralWidget);
// }

// // Green "Log" when logged in, yellow "Profile" when not
void MainWindow::updateProfileStyle()
{
    const QString textColor = isLoggedIn ? "green" : "black";

    profileMenu->setTitle(isLoggedIn ? "Log" : "Profile");

    profileBar->setStyleSheet(
        QString("QMenuBar { background-color: yellow; }"
                "QMenuBar::item { background-color: yellow; color: %1;"
                "                 padding: 5px 15px; font-weight: %2; }"
                "QMenuBar::item:selected { background-color: orange; }")
            .arg(textColor, isLoggedIn ? "bold" : "normal"));

    profileBar->adjustSize();

    loginAction->setEnabled(!isLoggedIn);
    logoutAction->setEnabled(isLoggedIn);
}



void MainWindow::initUI()
{
    // ---------- Colour palette ----------
    const QString cBg        = "#0B1F3A";   // main background
    const QString cPanel     = "#10243D";   // panels / menus
    const QString cPanelAlt  = "#173453";   // alternate surfaces
    const QString cAccent    = "#1976D2";   // buttons / headers
    const QString cAccentLt  = "#42A5F5";   // borders / hover
    const QString cText      = "#FFFFFF";

    // ---------- Header ----------
    QWidget *header = new QWidget(this);
    header->setObjectName("header");
    header->setFixedHeight(40);
    header->setStyleSheet(
        QString("#header { background-color: %1; border-bottom: 2px solid %2; }")
            .arg(cAccent, cAccentLt));

    QHBoxLayout *headerLayout = new QHBoxLayout(header);
    headerLayout->setContentsMargins(0, 0, 10, 0);
    headerLayout->setSpacing(0);

    // ---------- Menu bar style ----------
    const QString barStyle = QString(
                                 "QMenuBar { background-color: %1; color: %2; }"
                                 "QMenuBar::item {"
                                 " background-color: %1;"
                                 " color: %2;"
                                 " padding: 5px 15px;"
                                 "}"
                                 "QMenuBar::item:selected { background-color: %3; }"
                                 "QMenuBar::item:pressed  { background-color: %4; }")
                                 .arg(cAccent, cText, cAccentLt, "#1565C0");

    const QString menuStyle = QString(
                                  "QMenu {"
                                  " background-color: %1;"
                                  " color: %2;"
                                  " border: 1px solid %3;"
                                  "}"
                                  "QMenu::item {"
                                  " background-color: %1;"
                                  " color: %2;"
                                  " padding: 6px 25px;"
                                  "}"
                                  "QMenu::item:selected {"
                                  " background-color: %4;"
                                  " color: %2;"
                                  "}"
                                  "QMenu::item:disabled { color: #7A8CA3; }"
                                  "QMenu::separator { height: 1px; background: %3; margin: 4px 8px; }")
                                  .arg(cPanel, cText, cAccentLt, cAccent);

    // ---------- Menu bar ----------
    bar = new QMenuBar(header);
    bar->setNativeMenuBar(false);
    bar->setStyleSheet(barStyle);
    bar->setSizePolicy(QSizePolicy::Maximum, QSizePolicy::Fixed);

    // ---------- Menu ----------
    menu = bar->addMenu("Menu");
    menu->setStyleSheet(menuStyle);

    healthcheck = new QAction("Health", this);
    setTime = new QAction("SetTime", this);
    exit_1 = new QAction("Exit", this);

    menu->addAction(healthcheck);
    menu->addAction(setTime);
    menu->addAction(exit_1);

    // ---------- File ----------
    fileMenu = bar->addMenu("File");
    fileMenu->setStyleSheet(menuStyle);

    newAction = new QAction("New", this);
    openAction = new QAction("Open", this);
    exitAction = new QAction("Exit", this);

    fileMenu->addAction(newAction);
    fileMenu->addAction(openAction);
    fileMenu->addAction(exitAction);

    // ---------- View ----------
    viewMenu = bar->addMenu("View");
    viewMenu->setStyleSheet(menuStyle);

    headerLayout->addWidget(bar);
    headerLayout->addStretch();

    // =====================================================
    //                     SPLITTER
    // =====================================================
    QSplitter *splitter = new QSplitter(Qt::Vertical, this);
    splitter->setStyleSheet(
        QString("QSplitter::handle { background-color: %1; height: 4px; }"
                "QSplitter::handle:hover { background-color: %2; }")
            .arg(cAccent, cAccentLt));

    // ---------- Top panel (sent / received messages) ----------
    QWidget *topPanel = new QWidget();
    topPanel->setObjectName("topPanel");
    topPanel->setStyleSheet(
        QString("#topPanel { background-color: %1; }").arg(cBg));

    QVBoxLayout *topPanelLayout = new QVBoxLayout(topPanel);
    topPanelLayout->setContentsMargins(10, 10, 10, 10);
    topPanelLayout->setSpacing(0);

    select = new QPlainTextEdit(topPanel);
    select->setStyleSheet(
        QString("QPlainTextEdit {"
                "    background-color: %1;"
                "    color: %2;"
                "    border: 1px solid %3;"
                "    border-radius: 4px;"
                "    padding: 6px;"
                "    font-family: Consolas, monospace;"
                "    selection-background-color: %3;"
                "    selection-color: #FFFFFF;"
                "}"
                "QScrollBar:vertical { background: %1; width: 12px; }"
                "QScrollBar::handle:vertical { background: %4; border-radius: 5px; min-height: 24px; }"
                "QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }")
            .arg(cPanel, cText, cAccentLt, cAccent));

    select->setReadOnly(true);
    select->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    topPanelLayout->addWidget(select, 1);

    // ---------- Bottom panel ----------
    QWidget *bottomPanel = new QWidget();
    bottomPanel->setObjectName("bottomPanel");
    bottomPanel->setStyleSheet(
        QString("#bottomPanel { background-color: %1; }").arg(cPanel));

    QVBoxLayout *bottomPanelLayout = new QVBoxLayout(bottomPanel);
    bottomPanelLayout->setContentsMargins(0, 0, 0, 0);
    bottomPanelLayout->setSpacing(0);

    QWidget *bottomHeader = new QWidget();
    bottomHeader->setObjectName("bottomHeader");
    bottomHeader->setFixedHeight(40);
    bottomHeader->setStyleSheet(
        QString("#bottomHeader { background-color: %1; }").arg(cPanelAlt));

    bottomPanelLayout->addWidget(bottomHeader);
    bottomPanelLayout->addStretch();

    splitter->addWidget(topPanel);
    splitter->addWidget(bottomPanel);
    splitter->setSizes({300, 300});
    splitter->setChildrenCollapsible(false);

    // =====================================================
    //               MAIN WINDOW LAYOUT
    // =====================================================
    QWidget *centralWidget = new QWidget(this);
    centralWidget->setStyleSheet(QString("background-color: %1;").arg(cBg));

    QVBoxLayout *mainLayout = new QVBoxLayout(centralWidget);
    mainLayout->setContentsMargins(0, 0, 0, 0);
    mainLayout->setSpacing(0);

    mainLayout->addWidget(header);
    mainLayout->addWidget(splitter);

    setCentralWidget(centralWidget);
}
// void MainWindow::showDebugMessage(const QString &message,const QColor &color)
// {
//     QTextCursor cursor = select->textCursor();

//     cursor.movePosition(QTextCursor::End);

//     QTextCharFormat format;
//     format.setForeground(color);

//     cursor.insertText(
//         QDateTime::currentDateTime().toString("[hh:mm:ss] ")
//             + message + "\n",
//         format
//         );

//     select->setTextCursor(cursor);
//     select->ensureCursorVisible();
// }

void MainWindow::showDebugMessage(const QString &message, const QColor &color)
{
    // Only auto-scroll if the user is already at the bottom
    QScrollBar *sb = select->verticalScrollBar();
    const bool atBottom = sb->value() >= sb->maximum() - 4;

    // Separate cursor: doesn't change the user's selection or cursor
    QTextCursor cursor(select->document());
    cursor.movePosition(QTextCursor::End);

    // Timestamp (muted gray)
    QTextCharFormat timeFmt;
    timeFmt.setForeground(QColor("#7A8CA3"));
    cursor.insertText(
        QDateTime::currentDateTime().toString("[hh:mm:ss] "), timeFmt);

    // Message (chosen color)
    QTextCharFormat msgFmt;
    msgFmt.setForeground(color);
    cursor.insertText(message + "\n", msgFmt);

    // Keep the log from growing forever
    select->document()->setMaximumBlockCount(5000);

    if (atBottom)
        sb->setValue(sb->maximum());
}

// Convenience overload for sent / received / error
void MainWindow::showDebugMessage(const QString &message, MsgType type)
{
    QColor color;
    QString prefix;

    switch (type) {
    case MsgType::Sent:     color = QColor("#64B5F6"); prefix = "TX -> "; break;  // blue
    case MsgType::Received: color = QColor("#81C784"); prefix = "RX <- "; break;  // green
    case MsgType::Error:    color = QColor("#EF5350"); prefix = "ERR "  ; break;  // red
    case MsgType::Warning:  color = QColor("#FFB74D"); prefix = "WARN " ; break;  // orange
    case MsgType::Info:
    default:                color = QColor("#FFFFFF"); prefix = "";       break;
    }

    showDebugMessage(prefix + message, color);
}


/*
 *
 * showDebugMessage("Health command sent", MsgType::Sent);
showDebugMessage("Health OK",           MsgType::Received);
showDebugMessage("Connection lost",     MsgType::Error);
showDebugMessage("Custom color", QColor("#CE93D8"));   // old style still works/*


// =========================================================
//  Messages
// =========================================================
void MainWindow::sendTimeSynchronization()
{
    SetDataMessage timeSyncMsg{};

    QDateTime currentTime = QDateTime::currentDateTime();
    qDebug() << "System time:" << currentTime.toString("yyyy-MM-dd HH:mm:ss");

    timeSyncMsg.elapsedSeconds =
        static_cast<uint64_t>(currentTime.toSecsSinceEpoch());

    qDebug() << "Unix time:" << timeSyncMsg.elapsedSeconds;

    QByteArray data(reinterpret_cast<const char *>(&timeSyncMsg),
                    sizeof(SetDataMessage));
    connection->writeData(data);
}

void MainWindow::sendHealthCheck()
{
    HealthCheckMessage healthCheckMsg{};

    QByteArray data(reinterpret_cast<const char *>(&healthCheckMsg),
                    sizeof(HealthCheckMessage));

    qDebug() << "Health check is being sent";


    connection->writeData(data);
      qDebug() << "Data:" << data.toHex(' ').toUpper();

}

/*void MainWindow::selectFile()
{
    QStringList fileNames = QFileDialog::getOpenFileNames(
        this, "Select Input Files", "", "All Files (*.*)");

    if (fileNames.isEmpty())
        return;

    QStringList selectedNames;
    const QString destinationPath = "/home/sana/project";

    if (!QDir().mkpath(destinationPath))
    {
        qDebug() << "Failed to create destination folder:" << destinationPath;
        return;
    }

    bool allCopied = true;

    for (const QString &filePath : fileNames)
    {
        QFileInfo fileInfo(filePath);
        QString fileName = fileInfo.fileName();
        selectedNames << fileName;

        QString destinationFile = QDir(destinationPath).filePath(fileName);

        if (QFile::exists(destinationFile) && !QFile::remove(destinationFile))
        {
            qDebug() << "Failed to remove existing file:" << destinationFile;
            allCopied = false;
            continue;
        }

        if (QFile::copy(filePath, destinationFile))
            qDebug() << "File copied:" << destinationFile;
        else
        {
            qDebug() << "Failed to copy:" << filePath;
            allCopied = false;
        }
    }

    // Set before emitting, because sendMissionFileMessage() reads inputFiles
    inputFiles = selectedNames.join(", ");
  //  select->setText(inputFiles);

    if (allCopied)
    {
        qDebug() << "All files copied successfully.";
        emit fileCopyCompleted();
    }

    uint16_t count = static_cast<uint16_t>(fileNames.count());
    emit fileCount(count);

    qDebug() << "Input files:" << inputFiles;
    qDebug() << "File count:" << count;
}*/

void MainWindow::selectFile()
{
    // Open the custom file browser
    FileBrowserDialog dialog(this);

    if (dialog.exec() != QDialog::Accepted)
        return;

    // Get the selected file paths
    QStringList fileNames = dialog.selectedFiles();

    if (fileNames.isEmpty())
        return;

    QStringList selectedNames;

    const QString destinationPath = "/home/sana/project";

    if (!QDir().mkpath(destinationPath)) {
        qDebug() << "Failed to create destination folder:"
                 << destinationPath;
        return;
    }

    bool allCopied = true;

    for (const QString &filePath : fileNames) {
        QFileInfo fileInfo(filePath);

        QString fileName = fileInfo.fileName();
        selectedNames << fileName;

        QString destinationFile =
            QDir(destinationPath).filePath(fileName);

        if (QFile::exists(destinationFile)
            && !QFile::remove(destinationFile)) {
            qDebug() << "Failed to remove existing file:"
                     << destinationFile;
            allCopied = false;
            continue;
        }

        if (QFile::copy(filePath, destinationFile)) {
            qDebug() << "File copied:" << destinationFile;
        } else {
            qDebug() << "Failed to copy:" << filePath;
            allCopied = false;
        }
    }

    // Update the input file names before emitting signals
    inputFiles = selectedNames.join(", ");

    if (allCopied) {
        qDebug() << "All files copied successfully.";
        emit fileCopyCompleted();
    }

    const uint16_t count =
        static_cast<uint16_t>(fileNames.count());

    emit fileCount(count);

    qDebug() << "Input files:" << inputFiles;
    qDebug() << "File count:" << count;
}

void MainWindow::Tigger_ESC_filecout(uint16_t filecount)
{
    qDebug() << "Tigger_ESC_filecout" << filecount;

    TriggerMessage triggerMsg{};
    triggerMsg.inputFileCount = filecount;

    // TODO: send triggerMsg with connection->writeData(...) when needed
}

void MainWindow::sendMissionFileMessage()
{
    RawFileMessage missionMsg{};

    QByteArray fileName = inputFiles.toUtf8();

    if (static_cast<size_t>(fileName.size()) >= sizeof(missionMsg.missionIdFileName))
    {
        QMessageBox::warning(this, "Filename Too Long",
                             "File name must be less than 100 bytes.");
        return;
    }

    std::memcpy(missionMsg.missionIdFileName,
                fileName.constData(),
                fileName.size());
    missionMsg.missionIdFileName[fileName.size()] = '\0';

}

void MainWindow::buttoncliked()
{
    const QString username = lineEdit->text();
    const int usernameBytes = username.toUtf8().size();

    // Accept any non-empty username shorter than 10 UTF-8 bytes
    if (username.trimmed().isEmpty() || usernameBytes >= 10)
    {
        QMessageBox::warning(
            loginDialog,
            "Login Failed",
            "Username must not be empty and must be less than 10 bytes."
            );

        return;
    }

    radioCheaked_1 = radioButton1->isChecked();
    radioCheaked_2 = radioButton2->isChecked();

    if (!radioCheaked_1 && !radioCheaked_2)
    {
        QMessageBox::warning(
            loginDialog,
            "Login Failed",
            "Please select a user privilege."
            );

        return;
    }

    // Use your protocol's actual privilege mapping
    quint8 privilege = radioCheaked_1 ? 1 : 0;

    // Save details and send now or after connection
    connection->setLoginDetails(username, privilege);

    showDebugMessage("Login details accepted", Qt::green);

    // This closes the dialog after local validation.
    // For server-validated login, wait for its response instead.
    loginDialog->accept();
}
// void MainWindow::loginCredentials()
// {

//     if (!loginDetailsReady ||
//         socket->state() != QAbstractSocket::ConnectedState)
//     {
//         return;
//     }

//     LogDetailMessage msg{};

//     msg.startOfMessage = 0xC9;
//     msg.messageType = 0;
//     msg.commandCode = 0;
//     msg.sequenceNumber = sequenceNumber;
//     msg.messageLength = 0;  // Set according to your protocol

//     // Set privilege
//     if (radioCheaked_1)
//     {
//         msg.userPrivilege = 1;
//     }
//     else if (radioCheaked_2)
//     {
//         msg.userPrivilege = 0;
//     }

//     // Copy username into fixed-size array
//     QByteArray username = lineEdit->text().toUtf8();

//     for (qsizetype i = 0; i < username.size(); ++i)
//     {
//         msg.userName[i] = username.at(i);
//     }

//     msg.endOfMessage = 0xCF;

//     // Serialize message
//     QByteArray data;
//     QDataStream out(&data, QIODevice::WriteOnly);

//     out.setVersion(QDataStream::Qt_6_5);
//     out.setByteOrder(QDataStream::BigEndian);

//     out << quint8(msg.startOfMessage);
//     out << quint8(msg.messageType);
//     out << quint16(msg.commandCode);
//     out << quint16(msg.sequenceNumber);
//     out << quint16(msg.messageLength);

//     out.writeRawData(msg.userName, 10);

//     out << quint8(msg.userPrivilege);
//     out << quint8(msg.endOfMessage);

//     if (out.status() != QDataStream::Ok)
//     {
//         qDebug() << "Failed to serialize login message";
//         return;
//     }

//     // Send data
//     connection->writeData(data);

//     qDebug() << "Login message:" << data.toHex(' ');
//     qDebug() << "Sequence number:" << sequenceNumber;

//     ++sequenceNumber;
// }