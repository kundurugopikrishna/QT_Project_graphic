
#include "filebrowserdialog.h"

#include <QLabel>
#include <QPushButton>
#include <QDateEdit>
#include <QTableWidget>
#include <QCheckBox>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QFileDialog>
#include <QDirIterator>
#include <QFileInfo>
#include <QMessageBox>
#include <QDate>
#include <QDir>
#include <QAbstractItemView>
#include <QItemSelectionModel>
#include <QTableWidgetItem>
#include <QAbstractSpinBox>
FileBrowserDialog::FileBrowserDialog(QWidget *parent)
    : QDialog(parent)
{
    setWindowTitle("Custom File Browser");
    resize(950, 600);

    // Folder controls
    folderLabel = new QLabel("No folder selected", this);
    folderLabel->setTextInteractionFlags(
        Qt::TextSelectableByMouse);

    browseButton = new QPushButton("Browse Folder", this);
    refreshButton = new QPushButton("Refresh", this);

    // Calendar controls
    fromDateEdit = new MyDateEdit(this);
    toDateEdit = new MyDateEdit(this);

    fromDateEdit->setDate(
        QDate::currentDate().addMonths(-1));

    toDateEdit->setDate(
        QDate::currentDate());

    fromDateEdit->setDisplayFormat("dd-MM-yyyy");
    toDateEdit->setDisplayFormat("dd-MM-yyyy");
    // Enable calendar popup
    // fromDateEdit->setCalendarPopup(true);
    // toDateEdit->setCalendarPopup(true);

    // Display format
    fromDateEdit->setDisplayFormat("dd-MM-yyyy");
    toDateEdit->setDisplayFormat("dd-MM-yyyy");

    // Allow users to select dates using the calendar
    // fromDateEdit->setButtonSymbols(QAbstractSpinBox::UpDownArrows);
    // toDateEdit->setButtonSymbols(QAbstractSpinBox::UpDownArrows);

    // File scanning option
    recursiveCheckBox =
        new QCheckBox("Include subfolders", this);

    // File table
    fileTable = new QTableWidget(this);

    fileTable->setColumnCount(4);

    fileTable->setHorizontalHeaderLabels({
        "File Name",
        "File Type",
        "Size (Bytes)",
        "Last Modified"
    });

    fileTable->setEditTriggers(
        QAbstractItemView::NoEditTriggers);

    fileTable->setSelectionBehavior(
        QAbstractItemView::SelectRows);

    // Allow selecting multiple files
    fileTable->setSelectionMode(
        QAbstractItemView::ExtendedSelection);

    fileTable->setAlternatingRowColors(true);
    fileTable->setShowGrid(true);

    fileTable->horizontalHeader()->setSectionResizeMode(
        QHeaderView::Stretch);

    fileTable->verticalHeader()->setVisible(false);

    // Open and Cancel buttons
    openButton = new QPushButton("Open", this);
    cancelButton = new QPushButton("Cancel", this);

    openButton->setDefault(true);

    // Main layout
    auto *mainLayout = new QVBoxLayout(this);

    auto *folderLayout = new QHBoxLayout;
    folderLayout->addWidget(folderLabel, 1);
    folderLayout->addWidget(browseButton);

    auto *dateLayout = new QHBoxLayout;
    dateLayout->addWidget(new QLabel("From:", this));
    dateLayout->addWidget(fromDateEdit);
    dateLayout->addWidget(new QLabel("To:", this));
    dateLayout->addWidget(toDateEdit);
    dateLayout->addWidget(refreshButton);

    auto *buttonLayout = new QHBoxLayout;
    buttonLayout->addStretch();
    buttonLayout->addWidget(openButton);
    buttonLayout->addWidget(cancelButton);

    mainLayout->addLayout(folderLayout);
    mainLayout->addLayout(dateLayout);
    mainLayout->addWidget(recursiveCheckBox);
    mainLayout->addWidget(fileTable, 1);
    mainLayout->addLayout(buttonLayout);

    // Signals and slots
    connect(browseButton, &QPushButton::clicked, this,&FileBrowserDialog::chooseFolder);
    connect(fromDateEdit, &QDateEdit::dateChanged,
            this, [this](const QDate &) {
                refreshFiles();
            });

    connect(toDateEdit, &QDateEdit::dateChanged,
            this, [this](const QDate &) {
                refreshFiles();
            });
    connect(refreshButton, &QPushButton::clicked,this,&FileBrowserDialog::refreshFiles);

    connect(fromDateEdit,&QDateEdit::dateChanged,this,
            [this](const QDate &) {
                refreshFiles();
            });

    connect(toDateEdit,
            &QDateEdit::dateChanged,
            this,
            [this](const QDate &) {
                refreshFiles();
            });

    connect(recursiveCheckBox,
            &QCheckBox::toggled,
            this,
            [this](bool) {
                refreshFiles();
            });

    connect(openButton,
            &QPushButton::clicked,
            this,
            [this]() {
                if (selectedFiles().isEmpty()) {
                    QMessageBox::information(
                        this,
                        "No Files Selected",
                        "Please select at least one file.");
                    return;
                }

                accept();
            });

    connect(cancelButton,
            &QPushButton::clicked,
            this,
            &QDialog::reject);

    applyStyle();
}

void FileBrowserDialog::chooseFolder()
{
    const QString selectedFolder =
        QFileDialog::getExistingDirectory(
            this,
            "Select Folder",
            folderPath.isEmpty()
                ? QDir::homePath()
                : folderPath);

    if (selectedFolder.isEmpty())
        return;

    folderPath = selectedFolder;
    folderLabel->setText(folderPath);

    refreshFiles();
}

void FileBrowserDialog::refreshFiles()
{
    fileTable->setRowCount(0);

    if (folderPath.isEmpty())
        return;

    const QDate fromDate = fromDateEdit->date();
    const QDate toDate = toDateEdit->date();

    if (fromDate > toDate) {
        QMessageBox::warning(
            this,
            "Invalid Date Range",
            "The From date must be before or equal to the To date.");

        return;
    }

    QDirIterator::IteratorFlags flags{};

    if (recursiveCheckBox->isChecked())
        flags = QDirIterator::Subdirectories;

    QDirIterator iterator(
        folderPath,
        QDir::Files | QDir::NoDotAndDotDot,
        flags);

    while (iterator.hasNext()) {
        const QString path = iterator.next();
        const QFileInfo info(path);

        if (!info.exists() || !info.isFile())
            continue;

        // Use the file's last-modified date
        const QDate modifiedDate =
            info.lastModified().date();

        // Include both the From and To dates
        if (modifiedDate < fromDate ||
            modifiedDate > toDate) {
            continue;
        }

        const int row = fileTable->rowCount();
        fileTable->insertRow(row);

        // Store the full path for MainWindow
        auto *nameItem =
            new QTableWidgetItem(info.fileName());

        nameItem->setData(
            Qt::UserRole,
            info.absoluteFilePath());

        fileTable->setItem(row, 0, nameItem);

        fileTable->setItem(
            row, 1,
            new QTableWidgetItem(
                info.suffix().isEmpty()
                    ? "File"
                    : info.suffix().toUpper()));

        fileTable->setItem(
            row, 2,
            new QTableWidgetItem(
                QString::number(info.size())));

        fileTable->setItem(
            row, 3,
            new QTableWidgetItem(
                info.lastModified().toString(
                    "dd-MM-yyyy HH:mm:ss")));
    }
}

QStringList FileBrowserDialog::selectedFiles() const
{
    QStringList paths;

    const QModelIndexList rows =
        fileTable->selectionModel()->selectedRows();

    for (const QModelIndex &index : rows) {
        QTableWidgetItem *item =
            fileTable->item(index.row(), 0);

        if (item == nullptr)
            continue;

        const QString path =
            item->data(Qt::UserRole).toString();

        if (!path.isEmpty())
            paths << path;
    }

    return paths;
}




void FileBrowserDialog::applyStyle()
{
    setStyleSheet(R"(
        QDialog {
            background-color: #0B1F3A;
            color: white;
        }

        QLabel, QCheckBox {
            color: white;
        }

        QDateEdit {
            background-color: #142D4E;
            color: white;
            border: 1px solid #42A5F5;
            padding: 6px;
            border-radius: 4px;
        }

QCalendarWidget QAbstractItemView:disabled {
    color: #7A8CA3;
}
QCalendarWidget QMenu {
    background-color: #10243D;
    color: white;
}

// QDateEdit::down-arrow {
//     image: url(:/icons/calendar.png);   /* any icon in your .qrc */
//     width: 14px;
//     height: 14px;
// }


QCalendarWidget QSpinBox {
    background-color: #142D4E;
    color: white;
}
        QPushButton {
            background-color: #1976D2;
            color: white;
            border: none;
            padding: 8px 14px;
            border-radius: 4px;
        }

        QPushButton:hover {
            background-color: #42A5F5;
        }

        QPushButton:pressed {
            background-color: #1565C0;
        }

        QTableWidget {
            background-color: #10243D;
            color: white;
            alternate-background-color: #173453;
            gridline-color: #35516D;
            selection-background-color: #1976D2;
            selection-color: white;
            border: 1px solid #284767;
        }

        QTableWidget::item {
            padding: 5px;
        }

        QHeaderView::section {
            background-color: #1976D2;
            color: white;
            padding: 8px;
            border: none;
        }

        QCalendarWidget QWidget {
            background-color: #10243D;
            color: white;
        }

        QCalendarWidget QToolButton {
            background-color: #1976D2;
            color: white;
        }

        QCalendarWidget QAbstractItemView {
            background-color: #10243D;
            color: white;
            selection-background-color: #1976D2;
        }
    )");
}