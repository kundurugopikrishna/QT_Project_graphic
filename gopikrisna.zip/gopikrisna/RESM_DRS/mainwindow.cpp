#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QDataStream>
#include <QDebug>
#include <QTcpServer>
#include <QTcpSocket>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , server(new QTcpServer(this))
    , socket(nullptr)
    , dataprocessor(new DataProcessor(this))
{
    ui->setupUi(this);

    // Connect received data signal to processing function
    connect(this,&MainWindow::processData,this,&MainWindow::processReceivedData);
    connect(this,&MainWindow::healthStatus,dataprocessor,&DataProcessor::checkhealth);

    // Start TCP server
    startServer();
}

MainWindow::~MainWindow()
{
    if (socket)
    {
        socket->disconnectFromHost();
        socket->deleteLater();
        socket = nullptr;
    }

    if (server)
    {
        server->close();
    }

    delete ui;
}

void MainWindow::startServer()
{
    // Start TCP server on port 5000
    if (!server->listen(QHostAddress::Any, 5000))
    {
        qDebug() << "Server failed to start:"
                 << server->errorString();
        return;
    }

    qDebug() << "TCP Server started";
    qDebug() << "Listening on port:"
             << server->serverPort();

    // New client connection
    connect(server,
            &QTcpServer::newConnection,
            this,
            [this]()
            {
                // Get connected client socket
                socket = server->nextPendingConnection();

                qDebug() << "Client connected:"
                         << socket->peerAddress().toString()
                         << socket->peerPort();

                // Receive data


                dataprocessor->setSocket(socket);

                connect(socket,
                        &QTcpSocket::readyRead,
                        this,
                        &MainWindow::readClientData);

                // Client disconnected
                connect(socket,
                        &QTcpSocket::disconnected,
                        this,
                        [this]()
                        {
                            qDebug() << "Client disconnected";

                            socket->deleteLater();
                            socket = nullptr;
                        });
            });
}

void MainWindow::readClientData()
{
    if (!socket)
        return;

    QByteArray data = socket->readAll();

    if (data.isEmpty())
        return;

    qDebug() << "Received:"
             << data.toHex(' ').toUpper();

    // Send received data for processing
    emit processData(data);
}

// void MainWindow::writeData(const QByteArray &data)
// {
//     // 1. Check whether the socket exists
//     if (socket == nullptr) {
//         qDebug() << "Socket is null";
//         return;
//     }

//     // 2. Check whether the TCP connection is established
//     if (socket->state() != QAbstractSocket::ConnectedState) {
//         qDebug() << "TCP is not connected";
//         return;
//     }

//     // 3. Send data through TCP
//     qint64 bytesWritten = socket->write(data);

//     // 4. Check the result
//     if (bytesWritten == -1) {
//         qDebug() << "TCP write failed:"
//                  << socket->errorString();
//     } else {
//         qDebug() << "Bytes accepted for sending:"
//                  << bytesWritten;
//     }
// }
void MainWindow::processReceivedData(const QByteArray &data)
{
    // 1. Validate minimum header size
    if (data.size() < 4)
    {
        qDebug() << "Data too short:" << data.size();
        return;
    }

    // 2. Copy received data into a buffer
    QByteArray buffer = data;

    // 3. Read the command code from the buffer
    QDataStream stream(buffer);
    stream.setByteOrder(QDataStream::BigEndian);

    quint8 startByte = 0;
    quint8 messageType = 0;
    quint16 cmdCode = 0;

    stream >> startByte >> messageType >> cmdCode;

    if (stream.status() != QDataStream::Ok)
    {
        qDebug() << "Failed to read header";
        return;
    }

    qDebug() << "Start byte:" << Qt::hex << startByte;
    qDebug() << "Message type:" << Qt::hex << messageType;
    qDebug() << "Command code:" << Qt::hex << cmdCode;

    // 4. Check the command and forward the complete buffer
    if (cmdCode == 0xc500)
    {
        healthStatus(buffer);
    }


    else
    {
        qDebug() << "Unsupported command:" << Qt::hex << cmdCode;
    }
}

// void MainWindow::checkhealth(QByteArray status)
// {
//     Q_UNUSED(status);

//     // Health status processing will go here
// }
