#ifndef DATAPROCESSOR_H
#define DATAPROCESSOR_H

#include <QObject>
#include "Structdef.h"
#include <QMainWindow>
#include <QTcpSocket>   // Fix: declare QTcpSocket

class DataProcessor : public QObject
{
    Q_OBJECT
public:
    explicit DataProcessor(QObject *parent = nullptr);
    void checkhealth(const QByteArray &status);
    void Health();
    void setSocket(QTcpSocket *tcpSocket);
    QTcpSocket *socket = nullptr;

signals:
};

#endif // DATAPROCESSOR_H
