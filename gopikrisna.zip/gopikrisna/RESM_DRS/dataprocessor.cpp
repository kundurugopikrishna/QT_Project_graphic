#include "dataprocessor.h"

DataProcessor::DataProcessor(QObject *parent)
    : QObject{parent}
{


}

void DataProcessor::setSocket(QTcpSocket *tcpSocket)
{
    socket = tcpSocket;
}
void DataProcessor::checkhealth(const QByteArray &status)
{
    HealthCheckMessage healthcheck{};

    // 1. Check message size
    if (status.size() != sizeof(HealthCheckMessage))
    {
        qDebug() << "Invalid message size:"
                 << status.size()
                 << "Expected:"
                 << sizeof(HealthCheckMessage);
        return;
    }

    // 2. Read received data into the structure fields
    QDataStream stream(status);
    stream.setByteOrder(QDataStream::BigEndian);

    stream >> healthcheck.startOfMessage
        >> healthcheck.messageType
        >> healthcheck.commandCode
        >> healthcheck.sequenceNo
        >> healthcheck.messageLength
        >> healthcheck.endOfMessage;

    if (stream.status() != QDataStream::Ok)
    {
        qDebug() << "Failed to read health check message";
        return;
    }

    // 3. Validate all required fields
    bool valid = true;

    // if (healthcheck.startOfMessage != 0xC9)
    // {
    //     qDebug() << "Invalid startOfMessage:"
    //              << Qt::hex
    //              << healthcheck.startOfMessage;
    //     valid = false;
    // }

    // if (healthcheck.messageType != 0x81)
    // {
    //     qDebug() << "Invalid messageType:"
    //              << Qt::hex
    //              << healthcheck.messageType;
    //     valid = false;
    // }

    if (healthcheck.commandCode != 0xc500)
    {
        qDebug() << "Invalid commandCode:"
                 << Qt::hex
                 << healthcheck.commandCode;
        valid = false;
    }

    // qDebug() << "Sequence number:"
    //          << healthcheck.sequenceNo;

    // if (healthcheck.messageLength != 9)
    // {
    //     qDebug() << "Invalid messageLength:"
    //              << healthcheck.messageLength;
    //     valid = false;
    // }

    // if (healthcheck.endOfMessage != 0xCF)
    // {
    //     qDebug() << "Invalid endOfMessage:"
    //              << Qt::hex
    //              << healthcheck.endOfMessage;
    //     valid = false;
    // }

    // 4. Final result
    if (valid)
    {
        qDebug() << "Health check message is VALID";
        Health();

    }
    else
    {
        qDebug() << "Health check message is INVALID";
    }
}

void DataProcessor::Health()
{
    if (socket == nullptr ||
        socket->state() != QAbstractSocket::ConnectedState)
    {
        qDebug() << "TCP socket is not connected";
        return;
    }

    HealthStatus healthstatus{};

    healthstatus.startmsg = 0xC9;
    healthstatus.msgtype = 0x80;
    healthstatus.cmdcode = 0x00D5;
    healthstatus.seqno = 0;
    healthstatus.msglength = 0x0101;

    healthstatus.health_states_rfps = 0x0101;
    healthstatus.health_states_GPGPU =  0x0101;
    healthstatus.efmsg = 0xCF;

    // Create a byte array for transmission
    QByteArray data;

    // Write fields into the byte array
    QDataStream stream(&data, QIODevice::WriteOnly);
    stream.setByteOrder(QDataStream::BigEndian);

    stream << healthstatus.startmsg
           << healthstatus.msgtype
           << healthstatus.cmdcode
           << healthstatus.seqno
           << healthstatus.msglength
           << healthstatus.health_states_rfps
           << healthstatus.health_states_GPGPU
           << healthstatus.efmsg;

    if (stream.status() != QDataStream::Ok)
    {
        qDebug() << "Failed to serialize health status";
        return;
    }

    // Send the response through TCP
    qint64 bytesWritten = socket->write(data);

    if (bytesWritten == -1)
    {
        qDebug() << "TCP write failed:"
                 << socket->errorString();
    }
    else
    {
        qDebug() << "Health status bytes accepted:"
                 << bytesWritten;
        qDebug() << "Sent data:"
                 << data.toHex(' ');
    }
}