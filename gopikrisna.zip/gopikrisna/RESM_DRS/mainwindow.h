#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTcpServer>
#include <QTcpSocket>
#include "dataprocessor.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;
signals:
    void processData(QByteArray buffer);

    void healthStatus(const QByteArray &status);
private:
    Ui::MainWindow *ui;
     QTcpServer *server;
      QTcpSocket *socket;
     QByteArray receiveBuffer;

private slots:



    void processReceivedData(const QByteArray &data);
    void startServer();
    void readClientData();

   // void writeData(const QByteArray &data);

private:
    DataProcessor *dataprocessor;
};
#endif // MAINWINDOW_H
