#ifndef LOGPROFILE_H
#define LOGPROFILE_H

#include <QDialog>
#include <QMouseEvent>
#include <QPoint>
#include "Definclude.h"
class QLineEdit;
class QRadioButton;
class QPushButton;

class LogProfile : public QDialog
{
    Q_OBJECT

public:
    explicit LogProfile(QWidget *parent = nullptr);
    ~LogProfile();

    QString getUserName() const;
    bool isPrivilegeSelected() const;
    bool NONPrivilegeSelected() const;
private slots:
    void buttoncliked();
private:
    QLineEdit *lineEdit;
    QRadioButton *radioButton1;
    QRadioButton *radioButton2;
    QPoint dragPosition;

protected:
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;


};

#endif