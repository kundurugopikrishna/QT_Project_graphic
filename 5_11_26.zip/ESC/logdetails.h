ifndef LOGDETAILS_H
#define LOGDETAILS_H

#include <QObject>

class LogDetails : public QObject
{
    Q_OBJECT
public:
    explicit LogDetails(QObject *parent = nullptr);

signals:
};

#endif // LOGDETAILS_H
