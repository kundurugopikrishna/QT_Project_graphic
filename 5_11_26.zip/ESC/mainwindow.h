#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "Definclude.h"
#include "logprofile.h"
class QMenuBar;
class QMenu;
class QAction;
class QLabel;

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;
    LogDetailMessage logdetails{};
   // void showDebugMessage(const QString &message,const QColor &color);
    void FileAvailable(const QString data);
    bool loginpage();
    void buttoncliked();
    uint8_t radioCheaked_1;
    uint8_t radioCheaked_2;

public slots:
    void showDebugMessage(const QString &message, const QColor &color);
    void showDebugMessage(const QString &message, MsgType type);

signals:
    void fileCount(uint16_t count);
    void fileCopyCompleted();

private slots:
    void sendHealthCheck();
    void sendTimeSynchronization();
    void selectFile();
     void Tigger_ESC_filecout(const QString &destinationPath,uint16_t filecount);
    void sendMissionFileMessage();
   // void LoginDetails();
  //  void LogoutDetails();

  //  void sendLoginCredentials(QByteArray userdata);
    //void buttonClicked();
   // void closeButton();



    //void showDebugMessage(const QString &message,const QColor &color);
   // void non_privilegeduser();



private:
    void initUI();
    void updateProfileStyle();

    Ui::MainWindow *ui;
    TCPConn *connection;

    // Left menu bar
    QMenuBar *bar = nullptr;
    QMenu *menu = nullptr;
    QMenu *fileMenu = nullptr;
    QMenu *viewMenu = nullptr;

    QAction *healthcheck = nullptr;
    QAction *setTime = nullptr;
    QAction *exit_1 = nullptr;
    QAction *newAction = nullptr;
    QAction *openAction = nullptr;
    QAction *exitAction = nullptr;
    QAction *viewIPprort=nullptr;

    // Right menu bar (Profile)
    QMenuBar *profileBar = nullptr;
    QMenu *profileMenu = nullptr;
    QAction *loginAction = nullptr;
    QAction *logoutAction = nullptr;
    QAction *profileExitAction = nullptr;

    // Other
    QPlainTextEdit *select = nullptr;     // shows the selected file names
    QString inputFiles;

    bool isLoggedIn = false;
    QString currentUser;
    QString correctUsername = "admin";
  //  bool isLoggedIn = false;
    QString username;
    QString selectedOption;
    QRadioButton *radioButton1 = nullptr;
    QRadioButton *radioButton2 = nullptr;
    QLineEdit *usernameEdit;
     QLabel *usernameLabel ;

    QDialog *loginDialog;
    QLineEdit *lineEdit = nullptr;
    ESCTFGDData *esctfgdata=nullptr;
    LogProfile *logpage=nullptr;
    const QString destinationPath;
   // FileBrowserDialog *filebrowserdialog=nullptr;
};

#endif // MAINWINDOW_H