#ifndef ESCTFGDDATA_H
#define ESCTFGDDATA_H

#include <QWidget>
#include<QLabel>
#include <QDockWidget>
#include <QTableWidget>
#include <QTableWidgetItem>

class ESCTFGDData : public QWidget
{
    Q_OBJECT
public:
    explicit ESCTFGDData(QWidget *parent = nullptr);

signals:
private slots:
  // void SlotAppendFGD(stCtrlToResmFGAData *pcstFGAData);

private:
      void Init();
     QTableWidget *m_pctblTFGD=nullptr;
};

#endif // ESCTFGDDATA_H
