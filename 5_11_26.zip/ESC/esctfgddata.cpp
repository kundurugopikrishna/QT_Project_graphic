#include "esctfgddata.h"
#include<QHeaderView>
#include "Definclude.h"
ESCTFGDData::ESCTFGDData(QWidget *parent)
    : QWidget{parent}
{
    Init();

   // QLabel *label=new QLabel("shjsfshd",this);
}

// void ESCTFGDData::SlotAppendFGD(stCtrlToResmFGAData *pcstFGAData)
// {
//     if (pcstFGAData == nullptr)
//         return;

//     QTableWidgetItem *pctblWidItem = nullptr;

//     const Int32 iRow = m_pctblTFGD->rowCount();

//     m_pctblTFGD->insertRow(iRow);

//     // Continue with your existing 40-column insertion code



// }
void ESCTFGDData::Init()
{
    setWindowTitle("TFGD Data");

    QStringList strLst;

    strLst << "ModeInfo"
           << "ESM Trk No"
           << "RFPS Trk No"
           << "EI Lib Mat Flag"
           << "DataBase SrNo"
           << "Carrier Name"
           << "Carrier Class"
           << "Radar Name"
           << "Radar Mode"
           << "Conf Lvl"
           << "Emtr Type"
           << "Freq Type"
           << "PW Type"
           << "Mod Type"
           << "PRI Type"
           << "Scan Type"
           << "Freq Min"
           << "Freq Max"
           << "Freq Avg"
           << "PRI Min"
           << "PRI Max"
           << "PRI Avg"
           << "PW Min"
           << "PW Max"
           << "PW Avg"
           << "PRF Avg"
           << "Rise Time"
           << "Fall Time"
           << "No Agil Freq"
           << "No PRI Lvls"
           << "Jitter Percentage"
           << "Chirp Rate"
           << "Phase Code Len"
           << "Phase Code"
           << "Phase Code Chip Time"
           << "No Of Freq Steps"
           << "Step FM Min Freq"
           << "Step FM Max Freq"
           << "Step FM Bit Time"
           << "FM Dev";

    m_pctblTFGD = new QTableWidget(this);

    m_pctblTFGD->setColumnCount(strLst.count());
    m_pctblTFGD->setHorizontalHeaderLabels(strLst);

    m_pctblTFGD->setRowCount(0);

    m_pctblTFGD->setEditTriggers(QAbstractItemView::NoEditTriggers);
    m_pctblTFGD->setSelectionBehavior(QAbstractItemView::SelectRows);
    m_pctblTFGD->setSelectionMode(QAbstractItemView::SingleSelection);

    m_pctblTFGD->setAlternatingRowColors(true);

    // Header styling
    m_pctblTFGD->horizontalHeader()->setStyleSheet(
        "QHeaderView::section {"
        "    background-color: #263B55;"
        "    color: white;"
        "    padding: 8px;"
        "    border: 1px solid #3B526D;"
        "    font-weight: bold;"
        "}"
        "QHeaderView::section:hover {"
        "    background-color: #007F9E;"
        "    color: white;"
        "}"
        );

    // Table styling
    m_pctblTFGD->setStyleSheet(
        "QTableWidget {"
        "    background-color: #172536;"
        "    alternate-background-color: #1E3045;"
        "    color: #EAF2F8;"
        "    gridline-color: #354B63;"
        "    border: 1px solid #354B63;"
        "    selection-background-color: #087F9C;"
        "}"
        "QTableWidget::item:hover {"
        "    background-color: #29445F;"
        "    color: #00E5FF;"
        "}"
        );

    m_pctblTFGD->horizontalHeader()->setStretchLastSection(true);
    m_pctblTFGD->resizeColumnsToContents();

    // Layout
    QVBoxLayout *pLayout = new QVBoxLayout(this);
    pLayout->setContentsMargins(0, 0, 0, 0);
    pLayout->setSpacing(0);
    pLayout->addWidget(m_pctblTFGD);


}
