#ifndef DEFINCLUDE_H
#define DEFINCLUDE_H


#include <QString>
#include <cstdint>
#include<QPlainTextEdit>
#include "TCPConn.h"
#include <QSplitter>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QPushButton>
#include <QLabel>
#include <QLineEdit>
#include <QMessageBox>
#include <QDialog>
#include <QDateTime>
#include <QFile>
#include <QDir>
#include <QFileDialog>
#include <QFileInfo>
#include <QDebug>
#include <QMenuBar>
#include <QMenu>
#include <QAction>
#include <QGuiApplication>
#include <QApplication>
#include <cstring>
#include <QDialog>
#include "Structdef.h"
#include <QRadioButton>
#include<QHBoxLayout>
#include<QVBoxLayout>
#include<QButtonGroup>
#include "mydateedit.h"
#include "filebrowserdialog.h"
#include <QScrollBar>
#include <QLabel>
#include <QPushButton>
#include <QDateEdit>
#include <QTableWidget>
#include <QCheckBox>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QFileDialog>
#include <QDirIterator>
#include <QFileInfo>
#include <QMessageBox>
#include <QDate>
#include <QDir>
#include <QAbstractItemView>
#include <QItemSelectionModel>
#include <QTableWidgetItem>
#include <QAbstractSpinBox>
#include "esctfgddata.h"
#include <QLabel>
#include <QLineEdit>
#include <QRadioButton>
#include <QPushButton>
#include <QButtonGroup>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QGuiApplication>
#include <QScreen>
#include <QMouseEvent>

#endif // DEFINCLUDE_H
