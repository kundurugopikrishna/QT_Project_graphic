#include "logprofile.h"



LogProfile::LogProfile(QWidget *parent)
    : QDialog(parent)
{
    setWindowTitle("Login Dialog");
    setFixedSize(350, 200);

    // Remove title bar
    setWindowFlags(Qt::Dialog | Qt::FramelessWindowHint);

    // Center dialog
    QRect screenGeometry =
        QGuiApplication::primaryScreen()->availableGeometry();

    int x = (screenGeometry.width() - width()) / 2;
    int y = (screenGeometry.height() - height()) / 2;

    move(x, y);

    // Dialog styling
    setStyleSheet(R"(
        QDialog {
            background-color: #0B1F3A;
            border: 2px solid #1976D2;
        }

        QLabel {
            color: white;
            font-size: 14px;
            font-weight: bold;
        }

        QLineEdit {
            background-color: #142D4E;
            color: white;
            border: 1px solid #42A5F5;
            border-radius: 5px;
            padding: 6px;
        }

        QRadioButton {
            color: white;
            spacing: 8px;screenGeometry
        }

        QPushButton {
            background-color: #1976D2;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 8px;
            font-weight: bold;
        }

        QPushButton:hover {
            background-color: #2196F3;
        }
    )");

    // Title
    QLabel *titleLabel = new QLabel("USER LOGIN", this);

    titleLabel->setAlignment(Qt::AlignCenter);

    titleLabel->setStyleSheet(R"(
        QLabel {
            color: #42A5F5;
            font-size: 20px;
            font-weight: bold;
            padding: 10px;
        }
    )");

    // Username
    QLabel *label = new QLabel("Username:", this);

    lineEdit = new QLineEdit(this);
    lineEdit->setText("admin");
    lineEdit->setMaxLength(10);

    // Radio buttons
    radioButton1 = new QRadioButton("Privilege", this);
    radioButton2 = new QRadioButton("NON-Privilege", this);

    radioButton1->setChecked(true);

    QButtonGroup *radioGroup = new QButtonGroup(this);
    radioGroup->addButton(radioButton1);
    radioGroup->addButton(radioButton2);

    // Login button
    QPushButton *button = new QPushButton("Login", this);

    // Layouts
    QHBoxLayout *rowLayout = new QHBoxLayout;
    rowLayout->addWidget(label);
    rowLayout->addWidget(lineEdit);

    QHBoxLayout *radioLayout = new QHBoxLayout;
    radioLayout->addWidget(radioButton1);
    radioLayout->addWidget(radioButton2);

    QVBoxLayout *mainLayout = new QVBoxLayout(this);

    mainLayout->setContentsMargins(20, 15, 20, 20);
    mainLayout->setSpacing(12);

    mainLayout->addWidget(titleLabel);
    mainLayout->addLayout(rowLayout);
    mainLayout->addLayout(radioLayout);
    mainLayout->addSpacing(8);
    mainLayout->addWidget(button);

    // Login button connection
    connect(button, &QPushButton::clicked,
            this, [this]()
            {
                accept();});
    connect(button, &QPushButton::clicked, this, &LogProfile::buttoncliked);




}

LogProfile::~LogProfile()
{

}

// Get username
QString LogProfile::getUserName() const
{
    //return lineEdit->text();
    const QString name = lineEdit->text();
    qDebug() << "getUserName():" << name;
    return name;
}

// Get privilege selection
bool LogProfile::isPrivilegeSelected() const
{


    return radioButton1->isChecked();
}

bool LogProfile::NONPrivilegeSelected() const
{


    return radioButton2->isChecked();
}

// Mouse dragging
void LogProfile::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton)
    {
        dragPosition = event->globalPosition().toPoint()
        - frameGeometry().topLeft();

        event->accept();
    }
}

void LogProfile::mouseMoveEvent(QMouseEvent *event)
{
    if (event->buttons() & Qt::LeftButton)
    {
        move(event->globalPosition().toPoint() - dragPosition);
        event->accept();
    }
}

void LogProfile::buttoncliked()
{
    const QString username = lineEdit->text();

    if (username.trimmed().isEmpty() || username.toUtf8().size() >= 10)
    {
        // QMessageBox::warning(this, "Login Failed",
        //                      "Username must not be empty and must be less than 10 bytes.");
        return;
    }

    if (!radioButton1->isChecked() && !radioButton2->isChecked())
    {
        // QMessageBox::warning(this, "Login Failed",
        //                      "Please select a user privilege.");
        return;
    }

    accept();   // closes the dialog -> exec() returns Accepted
}