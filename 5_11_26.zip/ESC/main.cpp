#include "mainwindow.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    if (!w.loginpage())
        return 0;

    qRegisterMetaType<MsgType>("MsgType");
    w.show();

    return QApplication::exec();
}
