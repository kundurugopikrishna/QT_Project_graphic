#ifndef TCPCONN_H
#define TCPCONN_H

#include <QObject>
#include <QTcpSocket>
#include<QTimer>
#include <qdialog.h>
class TCPConn : public QObject
{
    Q_OBJECT
public:
    explicit TCPConn(QObject *parent = nullptr);
     ~TCPConn() override;
    void setLoginDetails(const QString &username,quint8 privilege);
    qint64 writeData(const QByteArray &data);
    void SettingDialog();
  //  bool connectcheck();

    //bool TCPflag=false;
     bool isConnected() const;
    QTcpSocket *socket;

signals:
    void showmessage(const QString &message, const QColor &color);

private slots:
void connectToServer();
void readServerData();
void disconnectioncheck();
void TCPConnected();
void loginCredentials();
void processReceivedData(const QByteArray &data);
void scheduleReconnect();

private:
QString serverAddress = "192.168.1.4";
quint16 serverPort = 5000;
bool loginDetailsReady =false;
uint16_t sequenceNumber;
quint8 userPrivilege = 0;
QString loginUserName;
QTimer *reconnectTimer;
QDialog *settingdialog=nullptr;
 QByteArray m_buffer;
 bool m_shuttingDown = false;

 QTimer *m_retryTimer = nullptr;


};

#endif // TCPCONN_H
