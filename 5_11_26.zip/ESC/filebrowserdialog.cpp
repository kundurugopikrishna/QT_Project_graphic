#include "filebrowserdialog.h"

#include <QAbstractItemView>
#include <QApplication>
#include <QCheckBox>
#include <QDate>
#include <QDateEdit>
#include <QDir>
#include <QDirIterator>
#include <QFileDialog>
#include <QFileInfo>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QItemSelectionModel>
#include <QLabel>
#include <QLocale>
#include <QMessageBox>
#include <QPushButton>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QVBoxLayout>

namespace {

// Role that holds the raw numeric value used for sorting
constexpr int SortKeyRole = Qt::UserRole + 1;

// Table item that displays text but sorts by a numeric key
// (so "100 KB" does not sort before "20 KB", and dates sort chronologically)
class SortableItem : public QTableWidgetItem
{
public:
    SortableItem(const QString &text, qint64 key)
        : QTableWidgetItem(text)
    {
        setData(SortKeyRole, key);
    }

    bool operator<(const QTableWidgetItem &other) const override
    {
        return data(SortKeyRole).toLongLong()
        < other.data(SortKeyRole).toLongLong();
    }
};

} // namespace


// Constructor
FileBrowserDialog::FileBrowserDialog(QWidget *parent)
    : QDialog(parent)
{
    setWindowTitle("Custom File Browser");
    resize(950, 600);

    // Folder controls
    folderLabel = new QLabel("No folder selected", this);
    folderLabel->setTextInteractionFlags(Qt::TextSelectableByMouse);

    browseButton = new QPushButton("Browse Folder", this);
    refreshButton = new QPushButton("Refresh", this);

    // Date controls
    fromDateEdit = new QDateEdit(this);
    toDateEdit = new QDateEdit(this);

    fromDateEdit->setDate(QDate::currentDate().addMonths(-1));
    toDateEdit->setDate(QDate::currentDate());

    fromDateEdit->setDisplayFormat("dd-MM-yyyy");
    toDateEdit->setDisplayFormat("dd-MM-yyyy");

    fromDateEdit->setCalendarPopup(true);
    toDateEdit->setCalendarPopup(true);

    // Recursive scanning option
    recursiveCheckBox = new QCheckBox("Include subfolders", this);

    // Status line (file count / validation messages)
    statusLabel = new QLabel(this);

    // File table
    fileTable = new QTableWidget(this);
    fileTable->setColumnCount(4);
    fileTable->setHorizontalHeaderLabels({
        "File Name",
        "File Type",
        "Size",
        "Last Modified"
    });

    fileTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    fileTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    fileTable->setSelectionMode(QAbstractItemView::ExtendedSelection);
    fileTable->setAlternatingRowColors(true);
    fileTable->setShowGrid(true);
    fileTable->verticalHeader()->setVisible(false);

    // File name stretches, other columns fit their contents
    QHeaderView *header = fileTable->horizontalHeader();
    header->setSectionResizeMode(0, QHeaderView::Stretch);
    header->setSectionResizeMode(1, QHeaderView::ResizeToContents);
    header->setSectionResizeMode(2, QHeaderView::ResizeToContents);
    header->setSectionResizeMode(3, QHeaderView::ResizeToContents);

    // Click a column header to sort
    fileTable->setSortingEnabled(true);

    // Open and Cancel buttons
    openButton = new QPushButton("Open", this);
    cancelButton = new QPushButton("Cancel", this);
    openButton->setDefault(true);

    // Layouts
    auto *mainLayout = new QVBoxLayout(this);

    auto *folderLayout = new QHBoxLayout;
    folderLayout->addWidget(folderLabel, 1);
    folderLayout->addWidget(browseButton);

    auto *dateLayout = new QHBoxLayout;
    dateLayout->addWidget(new QLabel("From:", this));
    dateLayout->addWidget(fromDateEdit);
    dateLayout->addWidget(new QLabel("To:", this));
    dateLayout->addWidget(toDateEdit);
    dateLayout->addWidget(refreshButton);

    auto *buttonLayout = new QHBoxLayout;
    buttonLayout->addWidget(statusLabel, 1);
    buttonLayout->addWidget(openButton);
    buttonLayout->addWidget(cancelButton);

    mainLayout->addLayout(folderLayout);
    mainLayout->addLayout(dateLayout);
    mainLayout->addWidget(recursiveCheckBox);
    mainLayout->addWidget(fileTable, 1);
    mainLayout->addLayout(buttonLayout);

    // Signal-slot connections
    connect(browseButton, &QPushButton::clicked,
            this, &FileBrowserDialog::chooseFolder);

    connect(refreshButton, &QPushButton::clicked,
            this, &FileBrowserDialog::refreshFiles);

    // Auto-refresh when filters change
    connect(fromDateEdit, &QDateEdit::dateChanged,
            this, &FileBrowserDialog::refreshFiles);
    connect(toDateEdit, &QDateEdit::dateChanged,
            this, &FileBrowserDialog::refreshFiles);
    connect(recursiveCheckBox, &QCheckBox::toggled,
            this, &FileBrowserDialog::refreshFiles);

    // Open button
    connect(openButton, &QPushButton::clicked, this, [this]() {
        if (selectedFiles().isEmpty()) {
            QMessageBox::information(
                this,
                "No Files Selected",
                "Please select at least one file.");
            return;
        }
        accept();
    });

    // Double-click a row to open
    connect(fileTable, &QTableWidget::cellDoubleClicked,
            this, [this]() { openButton->click(); });

    // Cancel button
    connect(cancelButton, &QPushButton::clicked,
            this, &QDialog::reject);

    applyStyle();
}


// Browse folder
void FileBrowserDialog::chooseFolder()
{
    const QString selectedFolder =
        QFileDialog::getExistingDirectory(
            this,
            "Select Folder",
            folderPath.isEmpty() ? QDir::homePath() : folderPath);

    if (selectedFolder.isEmpty())
        return;

    folderPath = selectedFolder;
    folderLabel->setText(folderPath);

    refreshFiles();
}


// Refresh files
void FileBrowserDialog::refreshFiles()
{
    fileTable->setRowCount(0);
    statusLabel->clear();

    if (folderPath.isEmpty())
        return;

    const QDate fromDate = fromDateEdit->date();
    const QDate toDate = toDateEdit->date();

    // Validate date range (shown in status line so auto-refresh
    // doesn't pop up dialogs while the user is still editing dates)
    if (fromDate > toDate) {
        statusLabel->setText(
            "The From date must be before or equal to the To date.");
        return;
    }

    QDirIterator::IteratorFlags flags = QDirIterator::NoIteratorFlags;
    if (recursiveCheckBox->isChecked())
        flags = QDirIterator::Subdirectories;

    const QDir baseDir(folderPath);

    QDirIterator iterator(
        folderPath,
        QDir::Files | QDir::NoDotAndDotDot,
        flags);

    QApplication::setOverrideCursor(Qt::WaitCursor);

    // Disable sorting and repainting while populating
    fileTable->setSortingEnabled(false);
    fileTable->setUpdatesEnabled(false);

    const QLocale locale;
    int row = 0;

    while (iterator.hasNext()) {
        const QString path = iterator.next();
        const QFileInfo info(path);

        if (!info.exists() || !info.isFile())
            continue;

        const QDateTime modified = info.lastModified();
        const QDate modifiedDate = modified.date();

        // Inclusive date range filter
        if (modifiedDate < fromDate || modifiedDate > toDate)
            continue;

        fileTable->insertRow(row);

        // File name (relative path so duplicates from subfolders are distinguishable)
        auto *nameItem = new QTableWidgetItem(
            recursiveCheckBox->isChecked()
                ? baseDir.relativeFilePath(path)
                : info.fileName());
        nameItem->setData(Qt::UserRole, info.absoluteFilePath());
        fileTable->setItem(row, 0, nameItem);

        // File type
        fileTable->setItem(row, 1, new QTableWidgetItem(
                                       info.suffix().isEmpty() ? "File" : info.suffix().toUpper()));

        // Size: human readable text, numeric sorting
        fileTable->setItem(row, 2, new SortableItem(
                                       locale.formattedDataSize(info.size()),
                                       info.size()));

        // Last modified: formatted text, chronological sorting
        fileTable->setItem(row, 3, new SortableItem(
                                       modified.toString("dd-MM-yyyy HH:mm:ss"),
                                       modified.toMSecsSinceEpoch()));

        ++row;
    }

    fileTable->setUpdatesEnabled(true);
    fileTable->setSortingEnabled(true);

    QApplication::restoreOverrideCursor();

    statusLabel->setText(QString("%1 file(s) found").arg(row));
}


// Get selected file paths
QStringList FileBrowserDialog::selectedFiles() const
{
    QStringList paths;

    const QModelIndexList rows =
        fileTable->selectionModel()->selectedRows();

    for (const QModelIndex &index : rows) {
        const QTableWidgetItem *item = fileTable->item(index.row(), 0);
        if (!item)
            continue;

        const QString path = item->data(Qt::UserRole).toString();
        if (!path.isEmpty())
            paths.append(path);
    }

    return paths;
}


// Stylesheet (replace with your own if you already have one)
// void FileBrowserDialog::applyStyle()
// {
//     setStyleSheet(R"(
//         QPushButton {
//             padding: 6px 14px;
//         }
//         QTableWidget {
//             gridline-color: #d0d0d0;
//         }
//         QHeaderView::section {
//             padding: 4px;
//             font-weight: bold;
//         }
//     )");
// }


void FileBrowserDialog::applyStyle()
{
    setStyleSheet(R"(
        QDialog {
            background-color: #0B1F3A;
            color: white;
        }

        QLabel, QCheckBox {
            color: white;
        }

        QDateEdit {
            background-color: #142D4E;
            color: white;
            border: 1px solid #42A5F5;
            padding: 6px;
            border-radius: 4px;
        }

QCalendarWidget QAbstractItemView:disabled {
    color: #7A8CA3;
}
QCalendarWidget QMenu {
    background-color: #10243D;
    color: white;
}

// QDateEdit::down-arrow {
//     image: url(:/icons/calendar.png);   /* any icon in your .qrc */
//     width: 14px;
//     height: 14px;
// }


QCalendarWidget QSpinBox {
    background-color: #142D4E;
    color: white;
}
        QPushButton {
            background-color: #1976D2;
            color: white;
            border: none;
            padding: 8px 14px;
            border-radius: 4px;
        }

        QPushButton:hover {
            background-color: #42A5F5;
        }

        QPushButton:pressed {
            background-color: #1565C0;
        }

        QTableWidget {
            background-color: #10243D;
            color: white;
            alternate-background-color: #173453;
            gridline-color: #35516D;
            selection-background-color: #1976D2;
            selection-color: white;
            border: 1px solid #284767;
        }

        QTableWidget::item {
            padding: 5px;
        }

        QHeaderView::section {
            background-color: #1976D2;
            color: white;
            padding: 8px;
            border: none;
        }

        QCalendarWidget QWidget {
            background-color: #10243D;
            color: white;
        }

        QCalendarWidget QToolButton {
            background-color: #1976D2;
            color: white;
        }

        QCalendarWidget QAbstractItemView {
            background-color: #10243D;
            color: white;
            selection-background-color: #1976D2;
        }
    )");
}