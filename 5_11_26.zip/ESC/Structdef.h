// #ifndef STRUCTDEF_H
// #define STRUCTDEF_H
// #include<QtGlobal>
// #include <cstdint>

// #pragma pack(push, 1)

// struct LogDetailMessage
// {
//     quint8  startOfMessage=0Xc9;   // 1 byte
//     quint8  messageType;      // 1 byte
//     quint16 commandCode;      // 2 bytes
//     quint16 sequenceNumber;   // 2 bytes
//     quint16 messageLength;    // 2 bytes
//     quint8  userPrivilege;    // 1 byte
//     char    userName[10];     // 10 bytes_SIZE_32_
//     quint8  endOfMessage;     // 1 byte
// };

// #pragma pack(pop)



// #pragma pack(push, 1)

// struct SetDataMessage
// {
//     uint8_t  startOfMessage = 0xC9;   // 1 byte
//     uint8_t  messageType    = 0x81;   // 1 byte
//     uint16_t commandCode    = 0xC4; // 2 bytes
//     uint16_t sequenceNo     = 0x0000; // 2 bytes
//     uint16_t messageLength  = 18;     // 2 bytes

//     char     referenceData[10] = {};  // 10 bytes

//     uint64_t elapsedSeconds = 0;       // 8 bytes

//     uint8_t  endOfMessage = 0xCF;      // 1 byte
// };

// #pragma pack(pop)


// #pragma pack(push, 1)

// struct HealthCheckMessage
// {
//     uint8_t  startOfMessage = 0xC9;   // 1 byte
//     uint8_t  messageType    = 0x81;   // 1 byte
//     uint16_t commandCode    = 0x00C5; // 2 bytes
//     uint16_t sequenceNo     = 0x0000; // 2 bytes
//     uint16_t messageLength  = 9;      // 2 bytes
//     uint8_t  endOfMessage   = 0xCF;   // 1 byte
// };




// #pragma pack(pop)

// #pragma pack(push, 1)

// struct TriggerMessage
// {
//     uint8_t  startOfMessage = 0xC9;   // 1 byte
//     uint8_t  messageType    = 0x81;   // 1 byte
//     uint16_t commandCode    = 0x00C1; // 2 bytes
//     uint16_t sequenceNo     = 0x0000; // 2 bytes
//     uint16_t messageLength  = 0x0000; // 2 bytes
//     uint8_t mode;
//     uint16_t inputFileCount = 0x0000; // 2 bytes

//     uint16_t lastStage      = 0x0000; // 2 bytes
//     uint16_t upcomingstage      = 0x0000; // 2 bytes

//     uint8_t  endOfMessage   = 0xCF;   // 1 byte
// };

// #pragma pack(pop)
// #pragma pack(push, 1)

// struct RawFileMessage
// {
//     uint8_t  startOfMessage = 0xC9;   // 1 byte
//     uint8_t  messageType    = 0x81;   // 1 byte
//     uint16_t commandCode    = 0x00C2; // 2 bytes
//     uint16_t sequenceNo     = 0x0000; // 2 bytes
//     uint16_t messageLength  = 200;    // 2 bytes

//     char missionIdFileName[200] = {}; // 200 bytes

//     uint8_t endOfMessage = 0xCF;      // 1 byte
// };
// #pragma pack(pop)



// #endif // STRUCTDEF_H




#ifndef STRUCTDEF_H
#define STRUCTDEF_H
#include <QtGlobal>
#include <array>
#include <qobject.h>

#define _SIZE_01_       1
#define _SIZE_02_       2
#define _SIZE_04_       4
#define _SIZE_08_       8

#define _SIZE_16_       16
#define _SIZE_32_       32
#define _SIZE_128_      128


//4 bytes











#pragma once

enum class MsgType { Info, Sent, Received, Error, Warning };
// Ensure structures use packed layout for protocol messages.
#pragma pack(push, 1)





#pragma pack(push, 1)
typedef struct stMMMStdDev
{
    float fMin;
    float fMax;
    float fMean;
    float fStdDev;

} stMMMStdDev;
#pragma pack(pop)


typedef struct stmeanstddev
{
    float fMean;
    float fStdDev;

} __attribute__((packed)) stMeanStdDev;


typedef struct stmmm
{
    float fMin;
    float fMax;
    float fMean;

} __attribute__((packed)) stMMM;


typedef struct stmm
{
    float fMean;
    float fMax;

} __attribute__((packed)) stMM;


typedef struct stmmb
{
    float fMinFreq;
    float fMaxFreq;
    float fBitTime;

} __attribute__((packed)) stMMB;


/*=====================================================================*/


#pragma pack(push, 1)

struct LogDetailMessage
{
    quint8  startOfMessage=0Xc9;   // 1 byte
    quint8  messageType;      // 1 byte
    quint16 commandCode;      // 2 bytes
    quint16 sequenceNumber;   // 2 bytes
    quint16 messageLength;    // 2 bytes
    quint8  userPrivilege;    // 1 byte
    char    userName[10];     // 10 bytes
    quint8  endOfMessage;     // 1 byte
};

#pragma pack(pop)




#pragma pack(push, 1)

struct HealthCheckMessage
{
    uint8_t  startOfMessage = 0xC9;   // 1 byte
    uint8_t  messageType    = 0x81;   // 1 byte
    uint16_t commandCode    = 0x00C5; // 2 bytes
    uint16_t sequenceNo     = 0x0000; // 2 bytes
    uint16_t messageLength  = 9;      // 2 bytes
    uint8_t  endOfMessage   = 0xCF;   // 1 byte
};

#pragma pack(push, 1)

typedef struct
{
    unsigned char  SetData_startmsg;
    unsigned char  SetData_msgtype;
    unsigned short cmdcode;
    unsigned short SetDataseqno;
    unsigned short msglength;

    unsigned short health_states_rfps;
    unsigned short health_states_GPGPU;

    unsigned char  efmsg;
} HealthStatus;
#pragma pack(pop)

#pragma pack(push, 1)


struct ASKResponse
{
    uint8_t startOfMessage;
    uint8_t messageType;
    uint8_t commandCode;
    uint8_t sequenceNo;
    uint8_t msglength;
    uint8_t secondcommandCode;
    uint8_t secondsequenceno;
    uint8_t Ack_Response;
    uint8_t subsystem_ID;
    uint8_t eod;

};

#pragma pack(pop)

#pragma pack(push, 1)

struct SetDataMessage
{
    uint8_t  startOfMessage = 0xC9;   // 1 byte
    uint8_t  messageType    = 0x81;   // 1 byte
    uint16_t commandCode    = 0x0000; // 2 bytes
    uint16_t sequenceNo     = 0x0000; // 2 bytes
    uint16_t messageLength  = 18;     // 2 bytes

    char     referenceData[10] = {};  // 10 bytes

    uint64_t elapsedSeconds = 0;       // 8 bytes

    uint8_t  endOfMessage = 0xCF;      // 1 byte
};

#pragma pack(pop)

#pragma pack(push, 1)

struct ProcessStatus
{
    uint8_t  startOfMessage = 0xC9;   // 1 byte
    uint8_t  messageType    = 0x81;   // 1 byte
    uint16_t commandCode    = 0xD2; // 2 bytes
    uint16_t sequenceNo     = 0x0000; // 2 bytes
    uint16_t messageLength  = 18;     // 2 bytes
    uint8_t currentprocess;
    std::array<char,200>Filename;
    uint64_t ClusterID;
    uint8_t processStatus;
    uint8_t  endOfMessage = 0xCF;



};
#pragma pack(pop)

#pragma pack(push, 1)
struct completeProcess{
    uint8_t  startOfMessage = 0xC9;   // 1 byte
    uint8_t  messageType    = 0x81;   // 1 byte
    uint16_t commandCode    = 0xD1; // 2 bytes
    uint16_t sequenceNo     = 0x0000; // 2 bytes
    uint16_t messageLength  = 18;     // 2 bytes
    uint16_t LastStage;
    uint16_t outputfile;
    uint8_t processStatus;
    uint8_t  endOfMessage = 0xCF;

};
#pragma pack(pop)



#pragma pack(push, 1)
struct Getrawfile
{
    uint8_t  startOfMessage = 0xC9;   // 1 byte
    uint8_t  messageType    = 0x81;   // 1 byte
    uint16_t commandCode    = 0xC2; // 2 bytes
    uint16_t sequenceNo     = 0x0000; // 2 bytes
    uint16_t messageLength  = 24;
    std::array<char,12>StartData;
    std::array<char,12>EndData;
    uint8_t  endOfMessage = 0xCF;
};
#pragma pack(pop)

struct RawFileMessage
{
    uint8_t  startOfMessage = 0xC9;   // 1 byte
    uint8_t  messageType    = 0x81;   // 1 byte
    uint16_t commandCode    = 0x00C2; // 2 bytes
    uint16_t sequenceNo     = 0x0000; // 2 bytes
    uint16_t messageLength  = 200;    // 2 bytes

    char missionIdFileName[200] = {}; // 200 bytes

    uint8_t endOfMessage = 0xCF;      // 1 byte
};
#pragma pack(pop)

#pragma pack(push, 1)

struct TriggerMessage
{
    uint8_t  startOfMessage = 0xC9;   // 1 byte
    uint8_t  messageType    = 0x81;   // 1 byte
    uint16_t commandCode    = 0x00C1; // 2 bytes
    uint16_t sequenceNo     = 0x0000; // 2 bytes
    uint16_t messageLength  = 0x0000; // 2 bytes
    uint8_t mode;
    uint16_t inputFileCount; // 2 bytes
    char inputfilelocation[200];//inputfile names delimited by ,
    uint16_t lastStage      = 0x0000; // 2 bytes
    uint16_t upcomingstage      = 0x0000; // 2 bytes

    uint8_t  endOfMessage   = 0xCF;   // 1 byte
};

#pragma pack(pop)
#pragma pack(push, 1)

//TRackData one
struct sttfgd_one_sam
{
    char  usNumOfTrks;
    char   usRFPSTrkNo;
    char   ucEmtrSignalType;
    char   ucFreqAgileType;
    char   ucFreqModuLaw;
    char   ucPWAgileType;
    char   ucModuType;
    char   ucNoOfAgileFreq;
    char   ucChirpType;
    char   ucLinChirpType;
    char   ucPhasCodeType;
    uint16_t  usPhasCodeLen;
    //Phase code 1-8
    uint8_t  ucPhaseCode1[_SIZE_04_];
    uint8_t   ucPhaseCode2[_SIZE_04_];
    uint8_t   ucPhaseCode3[_SIZE_04_];
    uint8_t   ucPhaseCode4[_SIZE_04_];
    uint8_t   ucPhaseCode5[_SIZE_04_];
    uint8_t   ucPhaseCode6[_SIZE_04_];
    uint8_t   ucPhaseCode7[_SIZE_04_];
    uint8_t   ucPhaseCode8[_SIZE_04_];
    char   ucNoofStepFreq;
    char   ucPRIType;
    char   ucPRIPatrnType;
    char   ucPRILevels;
    char   ucPWLevels;
    char   ucScanType;
    uint32_t  usNoPulses;

};
#pragma pack(pop)

#pragma pack(push, 1)

struct sttfgd_two_sam
{

    stMMMStdDev             ostAvgFreqStblTime;

    stMMMStdDev             ostSTFTAvgPeakFreq;

    float                   ostSTFTRngPeakFreq;

    stMMMStdDev              ostSTFTAvg3dbBW;

    stMMM                   ostSignalAmp;

    stMeanStdDev            ostRiseTime,ostFallTime;

    float                   fAgileFreq[_SIZE_32_],fAgileFreqBW;

    float                   fChirpRate,fDeviOrFMCW,fPhaseCode;

    stMMB                   ostStpdFM;

    float                   fFMDev;

    stMMMStdDev             ostPRI;

    float                   fJitter;

    stMMM                  ostDutyCycle;

    float                  fSpotPRI[_SIZE_128_],fPRIDwellTime[_SIZE_32_];

    stMMMStdDev             ostPW;

    float                   fAglPW[_SIZE_08_],fASP,fDwellTime,fBeamWid,fSideLbLvl;
    uint16_t                  usAntSecScnMin, usAntSecScnMax;
    float                   fSNR;

    char                    chFreqRemarks[100];
    char                    chPRIRemarks[100];
    char                    chPWRemarks[100];
    char                    chAntRemarks[100];
    char                    chGenRemarks[100];

    char                    ModPW[8][16];
    float                   Spare[100];

};
#pragma pack(pop)

Q_DECLARE_METATYPE(sttfgd_two_sam);


#endif // STRUCTDEF_H

