#ifndef FILEBROWSERDIALOG_H
#define FILEBROWSERDIALOG_H

#include <QDialog>
#include <QString>
#include <QStringList>

class QLabel;
class QPushButton;
class QDateEdit;
class QTableWidget;
class QCheckBox;

class FileBrowserDialog : public QDialog
{
    Q_OBJECT

public:
    explicit FileBrowserDialog(QWidget *parent = nullptr);

    // Full paths of the files selected in the table
    QStringList selectedFiles() const;

private slots:
    void chooseFolder();
    void refreshFiles();

private:
    void applyStyle();

    QString folderPath;

    QLabel *folderLabel = nullptr;
    QLabel *statusLabel = nullptr;
    QPushButton *browseButton = nullptr;
    QPushButton *refreshButton = nullptr;
    QDateEdit *fromDateEdit = nullptr;
    QDateEdit *toDateEdit = nullptr;
    QCheckBox *recursiveCheckBox = nullptr;
    QTableWidget *fileTable = nullptr;
    QPushButton *openButton = nullptr;
    QPushButton *cancelButton = nullptr;
};

#endif // FILEBROWSERDIALOG_H