#include "TCPConn.h"
#include "Structdef.h"

#include <QColor>
#include <QDataStream>
#include <QDebug>
#include <QDialog>
#include <QGridLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QTimer>

TCPConn::TCPConn(QObject *parent)
    : QObject{parent}
    , socket(new QTcpSocket(this))
{
    m_retryTimer = new QTimer(this);
    m_retryTimer->setSingleShot(true);
    m_retryTimer->setInterval(2000);

    connect(m_retryTimer, &QTimer::timeout, this, &TCPConn::connectToServer);
    connect(socket, &QTcpSocket::connected,    this, &TCPConn::TCPConnected);
    connect(socket, &QTcpSocket::disconnected, this, &TCPConn::disconnectioncheck);
    connect(socket, &QTcpSocket::readyRead,    this, &TCPConn::readServerData);

    connect(socket, &QTcpSocket::errorOccurred, this,
            [this](QAbstractSocket::SocketError)
            {
                if (m_shuttingDown)
                    return;
                emit showmessage(socket->errorString(), QColor(Qt::red));
                scheduleReconnect();
            });

    connectToServer();
}

TCPConn::~TCPConn()
{
    m_shuttingDown = true;
    m_retryTimer->stop();

    if (socket)
    {
        socket->disconnect(this);
        socket->abort();
    }
}

void TCPConn::setLoginDetails(const QString &username, quint8 privilege)
{
    loginUserName = username;
    userPrivilege = privilege;
    loginDetailsReady = true;

    qDebug()<<"setLoginDetails"<<loginUserName;
    // If already connected, send now; otherwise TCPConnected() sends it.
    if (isConnected())
        loginCredentials();
}

void TCPConn::connectToServer()
{
    if (m_shuttingDown || socket->state() != QAbstractSocket::UnconnectedState)
        return;

    const QString target = QString("%1:%2").arg(serverAddress).arg(serverPort);

    qDebug() << "Trying to connect to" << target;
    emit showmessage(QString("Trying to connect to %1").arg(target),
                     QColor(Qt::yellow));
    socket->connectToHost(serverAddress, serverPort);


}

void TCPConn::scheduleReconnect()
{
    if (m_shuttingDown)
        return;
    if (!m_retryTimer->isActive())
        m_retryTimer->start();
}

void TCPConn::disconnectioncheck()
{
    if (m_shuttingDown)
        return;

   // emit showmessage("Disconnected from server", QColor(Qt::red));
    emit showmessage(QString("Disconnected from %1:%2")
                         .arg(serverAddress).arg(serverPort),
                     QColor(Qt::red));
    m_buffer.clear();
    scheduleReconnect();
}

void TCPConn::TCPConnected()
{
    qDebug() << "Connected to server";
    emit showmessage("Connected to server", QColor(Qt::green));

    if (loginDetailsReady)
        loginCredentials();
    else
        qDebug() << "Login details are not ready yet";
}

void TCPConn::readServerData()
{
    const QByteArray data = socket->readAll();
    if (data.isEmpty())
        return;

    qDebug() << "Received:" << data.toHex(' ').toUpper();
    processReceivedData(data);
}

void TCPConn::loginCredentials()
{




    if (!loginDetailsReady || !isConnected())
        return;

    const QByteArray username = loginUserName.toUtf8();

    if (username.isEmpty() || username.size() >= 10)
    {
        qDebug() << "Invalid username length";
        emit showmessage("Invalid username length", QColor(Qt::red));
        return;
    }

    LogDetailMessage msg{};   // zero-initialised, so userName is padded with 0

    msg.startOfMessage = 0xC9;
    msg.messageType    = 0;
    msg.commandCode    = 0;
    msg.sequenceNumber = sequenceNumber;
    msg.messageLength  = 81;  // NOTE: serialized frame below is only 20 bytes, check protocol
    msg.userPrivilege  = userPrivilege;
    memcpy(msg.userName, username.constData(), username.size());
    msg.endOfMessage   = 0xCF;

    QByteArray data;
    QDataStream out(&data, QIODevice::WriteOnly);
    out.setByteOrder(QDataStream::BigEndian);

    out << quint8(msg.startOfMessage)
        << quint8(msg.messageType)
        << quint16(msg.commandCode)
        << quint16(msg.sequenceNumber)
        << quint16(msg.messageLength);
    out.writeRawData(msg.userName, 10);
    out << quint8(msg.userPrivilege)
        << quint8(msg.endOfMessage);

    if (out.status() != QDataStream::Ok)
    {
        qDebug() << "Failed to serialize login message";
        emit showmessage("Failed to build login message", QColor(Qt::red));
        return;
    }

    // Send through the common write function
    const qint64 written = writeData(data);
    qDebug() << "Login frame:" << data.toHex(' ').toUpper()
             << "size:" << data.size();

    if (written != data.size())
    {
        qDebug() << "Failed to queue complete login message";
        emit showmessage("Failed to send login message", QColor(Qt::red));
        return;
    }

    qDebug() << "Login message sent. Sequence number:" << sequenceNumber;

    ++sequenceNumber;
    qDebug() << "Login frame:" << data.toHex(' ').toUpper()
             << "size:" << data.size();
    emit showmessage("Login message sent", QColor(Qt::green));

}

bool TCPConn::isConnected() const
{
    return socket && socket->state() == QAbstractSocket::ConnectedState;
}

qint64 TCPConn::writeData(const QByteArray &data)
{
    if (!isConnected())
    {
        qDebug() << "TCP connection is not established!";
        emit showmessage("TCP connection is not established!", QColor(Qt::red));
        return -1;
    }

    qDebug() << "Data is sent:" << data.toHex(' ');
    return socket->write(data);
}

void TCPConn::processReceivedData(const QByteArray &data)
{
    // TCP is a byte stream: data may arrive split or merged, so accumulate it.
    m_buffer.append(data);

    constexpr int kHeaderSize = 8;   // start(1) type(1) cmd(2) seq(2) len(2)

    while (m_buffer.size() >= kHeaderSize)
    {
        // Resynchronise on the start byte
        if (quint8(m_buffer.at(0)) != 0xC9)
        {
            m_buffer.remove(0, 1);
            continue;
        }

        QDataStream stream(m_buffer);          // const read of the buffer
        stream.setByteOrder(QDataStream::BigEndian);

        quint8  startByte = 0, messageType = 0;
        quint16 cmdCode = 0, seq = 0, length = 0;
        stream >> startByte >> messageType >> cmdCode >> seq >> length;

        // ASSUMPTION: 'length' is the total frame size. Adjust if your protocol differs.
        if (length < kHeaderSize)
        {
            m_buffer.remove(0, 1);
            continue;
        }
        if (m_buffer.size() < length)
            return;                            // wait for the rest

        const QByteArray frame = m_buffer.left(length);
        m_buffer.remove(0, length);

        qDebug() << "Start byte:"   << Qt::hex << startByte
                 << "Message type:" << messageType
                 << "Command code:" << cmdCode;

        if (cmdCode == 0xC500)
        {
            // healthStatus(frame);
        }
        else
        {
            qDebug() << "Unsupported command:" << Qt::hex << cmdCode;
        }
    }
}

void TCPConn::SettingDialog()
{
    QDialog dialog;
    dialog.setWindowTitle("Server Settings");
    dialog.resize(400, 180);

    auto *ipLabel   = new QLabel("IP:",   &dialog);
    auto *portLabel = new QLabel("Port:", &dialog);

    auto *ipEdit   = new QLineEdit(serverAddress, &dialog);
    auto *portEdit = new QLineEdit(QString::number(serverPort), &dialog);
    ipEdit->setPlaceholderText("192.168.0.140");
    portEdit->setPlaceholderText("5000");

    auto *okButton    = new QPushButton("OK",    &dialog);
    auto *closeButton = new QPushButton("Close", &dialog);

    auto *layout = new QGridLayout(&dialog);
    layout->addWidget(ipLabel,    0, 0);
    layout->addWidget(ipEdit,     0, 1);
    layout->addWidget(portLabel,  1, 0);
    layout->addWidget(portEdit,   1, 1);
    layout->addWidget(okButton,   2, 0);
    layout->addWidget(closeButton,2, 1);

    connect(okButton, &QPushButton::clicked, &dialog, [&]()
            {
                const QString ip = ipEdit->text().trimmed();
                bool ok = false;
                const uint port = portEdit->text().toUInt(&ok);

                if (ip.isEmpty() || !ok || port == 0 || port > 65535)
                {
                    emit showmessage("Invalid IP or port", QColor(Qt::red));
                    return;
                }

                serverAddress = ip;
                serverPort    = static_cast<quint16>(port);
                dialog.accept();
            });
    connect(closeButton, &QPushButton::clicked, &dialog, &QDialog::reject);

    if (dialog.exec() == QDialog::Accepted)
    {
        // Apply new settings: drop the old connection; disconnectioncheck()
        // schedules a reconnect, or reconnect right away if already idle.
        m_retryTimer->stop();
        if (socket->state() != QAbstractSocket::UnconnectedState)
            socket->abort();      // abort() does not emit disconnected()
        connectToServer();
    }
}