#include "mainwindow.h"
#include "ui_mainwindow.h"

#include"TCPConn.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)

{
    ui->setupUi(this);
    this->showMaximized();
    connection = new TCPConn(this);


    this->hide();

    // if (loginPage())
    // {
    //     this->show();
    //    // loginDialog->exec();//close the dialog
    // }
    // else
    // {
    //     this->close();
    // }
    initUI();
   // non_privilegeduser();

    qDebug() << "Qt platform:" << QGuiApplication::platformName();

    // Menu actions
    connect(exit_1,      &QAction::triggered, this, &QWidget::close);
    connect(healthcheck, &QAction::triggered, this, &MainWindow::sendHealthCheck);
    connect(setTime,     &QAction::triggered, this, &MainWindow::sendTimeSynchronization);

    // File actions
    connect(exitAction,&QAction::triggered, this, &QWidget::close);
    connect(openAction,  &QAction::triggered, this, &MainWindow::selectFile);


    // Signals
    //connect(this, &MainWindow::fileCount,this, &MainWindow::Tigger_ESC_filecout);
    connect(this, &MainWindow::fileCopyCompleted,this,&MainWindow::sendMissionFileMessage);


    connect(viewIPprort,&QAction::triggered, connection, &TCPConn::SettingDialog);
    connect(connection,
            SIGNAL(showmessage(QString,QColor)),
            this,
            SLOT(showDebugMessage(QString,QColor)));

   //  connect(connection,&TCPConn::showmessage,this,&MainWindow::showDebugMessage);

}

MainWindow::~MainWindow()
{
    delete ui;
}

// =========================================================
//  UI
// =========================================================


void MainWindow::initUI()
{
    // ---------- Colour palette ----------
    const QString cBg        = "#0B1F3A";   // main background
    const QString cPanel     = "#10243D";   // panels / menus
    const QString cAccent    = "#1976D2";   // buttons / headers
    const QString cAccentLt  = "#42A5F5";   // borders / hover
    const QString cText      = "#FFFFFF";

    // ---------- Header ----------
    QWidget *header = new QWidget(this);
    header->setObjectName("header");
    header->setFixedHeight(40);
    header->setStyleSheet(
        QString("#header { background-color: %1; border-bottom: 2px solid %2; }")
            .arg(cAccent, cAccentLt));

    QHBoxLayout *headerLayout = new QHBoxLayout(header);
    headerLayout->setContentsMargins(0, 0, 10, 0);
    headerLayout->setSpacing(0);

    // ---------- Styles ----------
    const QString barStyle = QString(
                                 "QMenuBar { background-color: %1; color: %2; }"
                                 "QMenuBar::item {"
                                 " background-color: %1;"
                                 " color: %2;"
                                 " padding: 5px 15px;"
                                 "}"
                                 "QMenuBar::item:selected { background-color: %3; }"
                                 "QMenuBar::item:pressed  { background-color: %4; }")
                                 .arg(cAccent, cText, cAccentLt, "#1565C0");

    const QString menuStyle = QString(
                                  "QMenu {"
                                  " background-color: %1;"
                                  " color: %2;"
                                  " border: 1px solid %3;"
                                  "}"
                                  "QMenu::item {"
                                  " background-color: %1;"
                                  " color: %2;"
                                  " padding: 6px 25px;"
                                  "}"
                                  "QMenu::item:selected {"
                                  " background-color: %4;"
                                  " color: %2;"
                                  "}"
                                  "QMenu::item:disabled { color: #7A8CA3; }"
                                  "QMenu::separator { height: 1px; background: %3; margin: 4px 8px; }")
                                  .arg(cPanel, cText, cAccentLt, cAccent);

    // ---------- Main menu bar ----------
    bar = new QMenuBar(header);
    bar->setNativeMenuBar(false);
    bar->setStyleSheet(barStyle);
    bar->setSizePolicy(QSizePolicy::Maximum, QSizePolicy::Fixed);

    // Menu
    menu = bar->addMenu("Menu");
    menu->setStyleSheet(menuStyle);

    healthcheck = new QAction("Health", this);
    setTime     = new QAction("SetTime", this);
    exit_1      = new QAction("Exit", this);
    menu->addAction(healthcheck);
    menu->addAction(setTime);
    menu->addAction(exit_1);

    // File
    fileMenu = bar->addMenu("File");
    fileMenu->setStyleSheet(menuStyle);

    newAction  = new QAction("New", this);
    openAction = new QAction("Open", this);
    exitAction = new QAction("Exit", this);
    fileMenu->addAction(newAction);
    fileMenu->addAction(openAction);
    fileMenu->addAction(exitAction);

    // View
    viewMenu = bar->addMenu("View");
    viewMenu->setStyleSheet(menuStyle);

    viewIPprort = new QAction("Setting", this);
    viewMenu->addAction(viewIPprort);

    // ---------- Profile bar (this was the null widget) ----------
    if (!profileBar)
    {
        profileBar = new QMenuBar(header);
        profileBar->setNativeMenuBar(false);
        profileBar->setStyleSheet(barStyle);
        profileBar->setSizePolicy(QSizePolicy::Maximum, QSizePolicy::Fixed);
    }

    headerLayout->addWidget(bar);
    headerLayout->addStretch();
    headerLayout->addWidget(profileBar);

    // =====================================================
    //                     SPLITTER
    // =====================================================
    QSplitter *splitter = new QSplitter(Qt::Vertical, this);
    splitter->setStyleSheet(
        QString("QSplitter::handle { background-color: %1; height: 4px; }"
                "QSplitter::handle:hover { background-color: %2; }")
            .arg(cAccent, cAccentLt));

    // ---------- Top panel (log) ----------
    QWidget *topPanel = new QWidget();
    topPanel->setObjectName("topPanel");
    topPanel->setStyleSheet(
        QString("#topPanel { background-color: %1; }").arg(cBg));

    QVBoxLayout *topPanelLayout = new QVBoxLayout(topPanel);
    topPanelLayout->setContentsMargins(10, 10, 10, 10);
    topPanelLayout->setSpacing(0);

    select = new QPlainTextEdit(topPanel);
    select->setStyleSheet(
        QString("QPlainTextEdit {"
                "    background-color: %1;"
                "    color: %2;"
                "    border: 1px solid %3;"
                "    border-radius: 4px;"
                "    padding: 6px;"
                "    font-family: Consolas, monospace;"
                "    selection-background-color: %3;"
                "    selection-color: #FFFFFF;"
                "}"
                "QScrollBar:vertical { background: %1; width: 12px; }"
                "QScrollBar::handle:vertical { background: %4; border-radius: 5px; min-height: 24px; }"
                "QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }")
            .arg(cPanel, cText, cAccentLt, cAccent));
    select->setReadOnly(true);
    select->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    topPanelLayout->addWidget(select, 1);

    // ---------- Bottom panel (TFGD) ----------
    QWidget *bottomPanel = new QWidget();
    bottomPanel->setObjectName("bottomPanel");
    bottomPanel->setStyleSheet(
        QString("#bottomPanel { background-color: %1; }").arg(cAccent));

    QVBoxLayout *bottomPanelLayout = new QVBoxLayout(bottomPanel);
    bottomPanelLayout->setContentsMargins(0, 0, 0, 0);
    bottomPanelLayout->setSpacing(0);

    QWidget *bottomHeader = new QWidget();
    bottomHeader->setObjectName("bottomHeader");
    bottomHeader->setFixedHeight(40);
    bottomHeader->setStyleSheet(
        "QWidget#bottomHeader {"
        "    background-color: #263B55;"
        "    border-bottom: 2px solid #00B8D9;"
        "}");

    QHBoxLayout *tfgdLayout = new QHBoxLayout(bottomHeader);
    tfgdLayout->setContentsMargins(10, 0, 10, 0);
    tfgdLayout->setSpacing(5);

    QLabel *lblTFGD = new QLabel("TFGD", bottomHeader);
    lblTFGD->setObjectName("lblTFGD");
    lblTFGD->setStyleSheet(
        "QLabel#lblTFGD {"
        "    color: #FFFFFF;"
        "    font-size: 16px;"
        "    font-weight: bold;"
        "    background: transparent;"
        "    padding-left: 5px;"
        "}");
    tfgdLayout->addWidget(lblTFGD);
    tfgdLayout->addStretch();

    esctfgdata = new ESCTFGDData(bottomPanel);

    bottomPanelLayout->addWidget(bottomHeader);
    bottomPanelLayout->addWidget(esctfgdata);

    splitter->addWidget(topPanel);
    splitter->addWidget(bottomPanel);
    splitter->setSizes({300, 300});
    splitter->setChildrenCollapsible(false);

    // =====================================================
    //               MAIN WINDOW LAYOUT
    // =====================================================
    QWidget *centralWidget = new QWidget(this);
    centralWidget->setObjectName("centralWidget");
    // Scoped by object name so it doesn't override the children's own styles
    centralWidget->setStyleSheet(
        QString("#centralWidget { background-color: %1; }").arg(cBg));

    QVBoxLayout *mainLayout = new QVBoxLayout(centralWidget);
    mainLayout->setContentsMargins(0, 0, 0, 0);
    mainLayout->setSpacing(0);

    mainLayout->addWidget(header);
    mainLayout->addWidget(splitter);

    setCentralWidget(centralWidget);
}

bool MainWindow::loginpage()
{
    LogProfile dialog(this);
    loginDialog = &dialog;
    qDebug()<<"send this msg for the loginpage";
    bool success = (dialog.exec() == QDialog::Accepted);
    if (success)
    {
        const QString username   = dialog.getUserName();
        const bool privilege     = dialog.isPrivilegeSelected();      // radioButton1
        const bool nonprivilege  = dialog.NONPrivilegeSelected();     // radioButton2

        QString msg;
        MsgType type = MsgType::Info;

        if (privilege)
        {
            msg = "Logged in as: " + username + " (PRIVILEGED)";
        }
        else if (nonprivilege)
        {
            msg = "Logged in as: " + username + " (NON-PRIVILEGED)";
        }
        else
        {
            msg  = "Logged in as: " + username + " (no privilege selected)";
            type = MsgType::Warning;
        }

        qDebug().noquote() << msg;           // console
        showDebugMessage(msg, type);         // main window panel
        connection->setLoginDetails(username, privilege);

    }
    else
    {
        qDebug() << "Login cancelled";
        showDebugMessage("Login cancelled", MsgType::Warning);
    }

    loginDialog = nullptr;
    return success;
}

void MainWindow::buttoncliked()
{

    qDebug()<<"this mag is for the buttoncliked";
    const QString username = lineEdit->text();
    const int usernameBytes = username.toUtf8().size();

    // Accept any non-empty username shorter than 10 UTF-8 bytes
    if (username.trimmed().isEmpty() || usernameBytes >= 10)
    {
        QMessageBox::warning(
            loginDialog,
            "Login Failed",
            "Username must not be empty and must be less than 10 bytes."
            );

        return;
    }

    radioCheaked_1 = radioButton1->isChecked();
    radioCheaked_2 = radioButton2->isChecked();

    if (!radioCheaked_1 && !radioCheaked_2)
    {
        QMessageBox::warning(
            loginDialog,
            "Login Failed",
            "Please select a user privilege."
            );

        return;
    }

    // Use your protocol's actual privilege mapping
    quint8 privilege = radioCheaked_1 ? 1 : 0;

    // Save details and send now or after connection
  //  connection->setLoginDetails(username, privilege);

    showDebugMessage("Login details accepted", Qt::green);

    // This closes the dialog after local validation.
    // For server-validated login, wait for its response instead.
    loginDialog->accept();
}

// void MainWindow::showDebugMessage(const QString &message,const QColor &color)
// {
//     QTextCursor cursor = select->textCursor();

//     cursor.movePosition(QTextCursor::End);

//     QTextCharFormat format;
//     format.setForeground(color);

//     cursor.insertText(
//         QDateTime::currentDateTime().toString("[hh:mm:ss] ")
//             + message + "\n",
//         format
//         );

//     select->setTextCursor(cursor);
//     select->ensureCursorVisible();
// }










void MainWindow::showDebugMessage(const QString &message, const QColor &color)
{
    // Only auto-scroll if the user is already at the top
    QScrollBar *sb = select->verticalScrollBar();
    const bool atTop = sb->value() <= sb->minimum() + 4;

    // Separate cursor: doesn't change the user's selection or cursor
    QTextCursor cursor(select->document());
    cursor.beginEditBlock();
    cursor.movePosition(QTextCursor::Start);          // was: End

    // Timestamp (muted gray)
    QTextCharFormat timeFmt;
    timeFmt.setForeground(QColor("#7A8CA3"));
    cursor.insertText(
        QDateTime::currentDateTime().toString("[hh:mm:ss] "), timeFmt);

    // Message (chosen color)
    QTextCharFormat msgFmt;
    msgFmt.setForeground(color);
    cursor.insertText(message + "\n", msgFmt);
    cursor.endEditBlock();

    // Keep the log from growing forever (trim the OLDEST lines, which are now at the bottom)
    const int maxBlocks = 5000;
    QTextDocument *doc = select->document();
    if (doc->blockCount() > maxBlocks)
    {
        QTextCursor trim(doc);
        trim.movePosition(QTextCursor::End);
        while (doc->blockCount() > maxBlocks)
        {
            trim.select(QTextCursor::BlockUnderCursor);
            trim.removeSelectedText();
        }
    }

    if (atTop)
        sb->setValue(sb->minimum());
}

// Convenience overload for sent / received / error
void MainWindow::showDebugMessage(const QString &message, MsgType type)
{
    QColor color;
    QString prefix;

    switch (type) {
    case MsgType::Sent:     color = QColor("#64B5F6"); prefix = "TX -> "; break;  // blue
    case MsgType::Received: color = QColor("#81C784"); prefix = "RX <- "; break;  // green
    case MsgType::Error:    color = QColor("#EF5350"); prefix = "ERR "  ; break;  // red
    case MsgType::Warning:  color = QColor("#FFB74D"); prefix = "WARN " ; break;  // orange
    case MsgType::Info:
    default:                color = QColor("#FFFFFF"); prefix = "";       break;
    }

    showDebugMessage(prefix + message, color);
}
















void MainWindow::FileAvailable(const QString data)
{
    RawFileMessage rawfilename{};

    showDebugMessage(" copied successfully",Qt::green);

   // rawfilename.missionIdFileName=data;


    QByteArray buffer(reinterpret_cast<const char*>(&rawfilename),sizeof(RawFileMessage));

    connection->writeData(buffer);


}

void MainWindow::sendTimeSynchronization()
{
    SetDataMessage timeSyncMsg{};

    // Get current system time
    QDateTime currentTime = QDateTime::currentDateTime();

    // Print present date and time
    qDebug() << "Present Date and Time:"
             << currentTime.toString("yyyy-MM-dd HH:mm:ss");

    showDebugMessage("Present Date and Time::",Qt::green);


    // Unix timestamp in seconds
    timeSyncMsg.elapsedSeconds =
        static_cast<uint64_t>(currentTime.toSecsSinceEpoch());

    qDebug() << "Unix Timestamp:"
             << timeSyncMsg.elapsedSeconds;

    // Serialize message in big-endian format
    QByteArray data;
    QDataStream stream(&data, QIODevice::WriteOnly);

    stream.setByteOrder(QDataStream::BigEndian);

    stream << static_cast<quint8>(timeSyncMsg.startOfMessage);
    stream << static_cast<quint8>(timeSyncMsg.messageType);
    stream << static_cast<quint16>(timeSyncMsg.commandCode);
    stream << static_cast<quint16>(timeSyncMsg.sequenceNo);
    stream << static_cast<quint16>(timeSyncMsg.messageLength);

    // Reference data: 10 bytes
    stream.writeRawData(
        timeSyncMsg.referenceData,
        sizeof(timeSyncMsg.referenceData));

    // Unix timestamp: 8 bytes, big-endian
    stream << static_cast<quint64>(timeSyncMsg.elapsedSeconds);

    // End marker
    stream << static_cast<quint8>(timeSyncMsg.endOfMessage);

    qDebug() << "Message size:" << data.size();
    qDebug() << "Message HEX:" << data.toHex(' ').toUpper();

    // Send through TCP
    // if (connection != nullptr)
    // {
    //     connection->writeData(data);
    //     qDebug() << "Time synchronization message sent.";
    //     showDebugMessage("Time synchronization message sent.",Qt::green);


    // }
    // else
    // {
    //     qDebug() << "TCP connection is null!";

    //       showDebugMessage("TCP connection is null!",Qt::red);
    // }


  //  qint64 bytesWritten = connection->socket->write(data);
    qint64 bytesWritten = connection->writeData(data);

    if (bytesWritten == data.size())
    {
        qDebug() << "TimeSynchronization message queued successfully!";
        showDebugMessage("TimeSynchronization message sent!", Qt::green);
    }
    else if (bytesWritten == -1)
    {
        qDebug() << "Failed to send TimeSynchronization message:"
                 << connection->socket->errorString();

        showDebugMessage(
            "Failed to send TimeSynchronization message: " +
                connection->socket->errorString(),
            Qt::red
            );
    }
    else
    {
        qDebug() << "TimeSynchronization message partially queued:"
                 << bytesWritten << "of" << data.size() << "bytes";

        showDebugMessage("TimeSynchronizationk message partially queued!", Qt::red);
    }
}

void MainWindow::sendHealthCheck()
{
    // Check whether the TCP connection object exists
    if (connection == nullptr)
    {
        qDebug() << "TCP connection object is null!";
        showDebugMessage("TCP connection object is null!", Qt::red);
        return;
    }

    // Check whether the socket exists and is connected
    if (connection->socket == nullptr ||
        connection->socket->state() != QAbstractSocket::ConnectedState)
    {
        qDebug() << "TCP connection is not established!";
        showDebugMessage("TCP connection is not established!", Qt::red);
        return;
    }

    // Create the health-check message
    HealthCheckMessage healthCheckMsg{};

    QByteArray data;
    QDataStream stream(&data, QIODevice::WriteOnly);

    // Set big-endian byte order
    stream.setByteOrder(QDataStream::BigEndian);

    // Serialize each field
    stream << static_cast<quint8>(healthCheckMsg.startOfMessage);
    stream << static_cast<quint8>(healthCheckMsg.messageType);
    stream << static_cast<quint16>(healthCheckMsg.commandCode);
    stream << static_cast<quint16>(healthCheckMsg.sequenceNo);
    stream << static_cast<quint16>(healthCheckMsg.messageLength);
    stream << static_cast<quint8>(healthCheckMsg.endOfMessage);

    // Check serialization status
    if (stream.status() != QDataStream::Ok)
    {
        qDebug() << "Failed to serialize health-check message!";
        showDebugMessage("Failed to serialize health-check message!", Qt::red);
        return;
    }

    qDebug() << "Health check is being sent";
    showDebugMessage("Health check is being sent", Qt::green);

    qDebug() << "Message size:" << data.size();
    qDebug() << "Data:" << data.toHex(' ').toUpper();

    // Send data through the TCP connection
  //  qint64 bytesWritten = connection->socket->write(data);
     qint64 bytesWritten = connection->writeData(data);

    if (bytesWritten == data.size())
    {
        qDebug() << "Health-check message queued successfully!";
        showDebugMessage("Health-check message sent!", Qt::green);
    }
    else if (bytesWritten == -1)
    {
        qDebug() << "Failed to send health-check message:"
                 << connection->socket->errorString();

        showDebugMessage(
            "Failed to send health-check message: " +
                connection->socket->errorString(),
            Qt::red
            );
    }
    else
    {
        qDebug() << "Health-check message partially queued:"
                 << bytesWritten << "of" << data.size() << "bytes";

        showDebugMessage("Health-check message partially queued!", Qt::red);
    }
}





// void MainWindow::selectFile()
// {
//     // Open the custom file browser
//     FileBrowserDialog dialog(this);

//     if (dialog.exec() != QDialog::Accepted)
//     {
//         showDebugMessage("File selection cancelled", MsgType::Warning);
//         return;
//     }

//     QStringList fileNames = dialog.selectedFiles();

//     if (fileNames.isEmpty())
//     {
//         showDebugMessage("No file selected", MsgType::Warning);
//         return;
//     }

//     QStringList selectedNames;

//     const QString destinationPath = "/home/sana/project";



//     if (!QDir().mkpath(destinationPath)) {
//         qDebug() << "Failed to create destination folder:" << destinationPath;
//         showDebugMessage("Failed to create destination folder: " + destinationPath,
//                          MsgType::Error);
//         return;
//     }

//     bool allCopied = true;

//     for (const QString &filePath : fileNames) {
//         QFileInfo fileInfo(filePath);

//         QString fileName = fileInfo.fileName();
//         selectedNames << fileName;

//         QString destinationFile = QDir(destinationPath).filePath(fileName);

//         if (QFile::exists(destinationFile)
//             && !QFile::remove(destinationFile)) {
//             qDebug() << "Failed to remove existing file:" << destinationFile;
//             showDebugMessage("Failed to remove existing file: " + destinationFile,
//                              MsgType::Error);
//             allCopied = false;
//             continue;
//         }

//         if (QFile::copy(filePath, destinationFile)) {
//             qDebug() << "File copied:" << destinationFile;
//             showDebugMessage("File copied: " + destinationFile, MsgType::Info);
//         } else {
//             qDebug() << "Failed to copy:" << filePath;
//             showDebugMessage("Failed to copy: " + filePath, MsgType::Error);
//             allCopied = false;
//         }
//     }

//     // Update the input file names before emitting signals
//     inputFiles = selectedNames.join(", ");

//     const uint16_t count = static_cast<uint16_t>(fileNames.count());

//     qDebug() << "Input files:" << inputFiles;
//     qDebug() << "File count:" << count;

//     Tigger_ESC_filecout(destinationPath,count);
//     showDebugMessage("Input files (" + QString::number(count) + "): " + inputFiles,
//                      MsgType::Info);

//     // emit fileCount(count);

//     if (allCopied) {
//         showDebugMessage("All files copied successfully", MsgType::Info);

//         // fileCopyCompleted is connected to sendMissionFileMessage(),
//         // so do NOT call sendMissionFileMessage() again here
//         // (that would send the message twice).
//         emit fileCopyCompleted();
//     } else {
//         showDebugMessage("Some files failed to copy - mission message not sent",
//                          MsgType::Warning);
//     }
// }


void MainWindow::selectFile()
{
    FileBrowserDialog dialog(this);

    if (dialog.exec() != QDialog::Accepted)
    {
        showDebugMessage("File selection cancelled", MsgType::Warning);
        return;
    }

    QStringList fileNames = dialog.selectedFiles();

    if (fileNames.isEmpty())
    {
        showDebugMessage("No file selected", MsgType::Warning);
        return;
    }

    const QString destinationPath = "/home/sana/project";

    if (!QDir().mkpath(destinationPath))
    {
        showDebugMessage("Failed to create destination folder",
                         MsgType::Error);
        return;
    }

    QStringList selectedNames;
    bool allCopied = true;

    for (const QString &filePath : fileNames)
    {
        QFileInfo fileInfo(filePath);

        QString fileName = fileInfo.fileName();
        QString destinationFile =
            QDir(destinationPath).filePath(fileName);

        if (QFile::exists(destinationFile))
        {
            if (!QFile::remove(destinationFile))
            {
                allCopied = false;
                continue;
            }
        }

        if (QFile::copy(filePath, destinationFile))
        {
            selectedNames << fileName;

            showDebugMessage("File copied: " + destinationFile,
                             MsgType::Info);
        }
        else
        {
            allCopied = false;

            showDebugMessage("Failed to copy: " + filePath,
                             MsgType::Error);
        }
    }

    if (selectedNames.isEmpty())
    {
        showDebugMessage("No files copied successfully",
                         MsgType::Error);
        return;
    }

    inputFiles = selectedNames.join(", ");

    uint16_t count =
        static_cast<uint16_t>(selectedNames.count());

    qDebug() << "Input files:" << inputFiles;
    qDebug() << "File count:" << count;

    Tigger_ESC_filecout(destinationPath, count);
}

void MainWindow::Tigger_ESC_filecout(
    const QString &destinationPath,
    uint16_t filecount)
{
    qDebug() << "Tigger_ESC_filecout" << filecount;

    TriggerMessage triggerMsg{};

    // Update structure fields
    triggerMsg.startOfMessage = 0xC9;
    triggerMsg.messageType = 0x81;
    triggerMsg.commandCode = 0x00C1;
    triggerMsg.sequenceNo = 0x0000;

    triggerMsg.mode = 0x01;  // Set your required mode

    triggerMsg.inputFileCount = filecount;

    // Convert destination path into UTF-8
    QByteArray pathData = destinationPath.toUtf8();

    if (pathData.size() >=
        static_cast<int>(sizeof(triggerMsg.inputfilelocation)))
    {
        showDebugMessage("Destination path is too long",
                         MsgType::Error);
        return;
    }

    // Copy path into structure
    std::memcpy(triggerMsg.inputfilelocation,
                pathData.constData(),
                pathData.size());

    triggerMsg.inputfilelocation[pathData.size()] = '\0';

    triggerMsg.lastStage = 0x0000;
    triggerMsg.upcomingstage = 0x0000;

    triggerMsg.endOfMessage = 0xCF;

    // Calculate message length
    triggerMsg.messageLength =
        sizeof(triggerMsg) -
        sizeof(triggerMsg.startOfMessage) -
        sizeof(triggerMsg.endOfMessage);

    qDebug() << "Trigger ESC file count:"
             << triggerMsg.inputFileCount;

    qDebug() << "Destination:"
             << triggerMsg.inputfilelocation;

    showDebugMessage("Trigger ESC file count: " +
                         QString::number(filecount),
                     MsgType::Info);

    // Send message
    QByteArray data(
        reinterpret_cast<const char*>(&triggerMsg),
        sizeof(TriggerMessage));

    connection->writeData(data);
}
void MainWindow::sendMissionFileMessage()
{
    RawFileMessage missionMsg{};

    QByteArray fileName = inputFiles.toUtf8();

    qDebug()<<"filename sendMissionFileMessage"<<fileName;

    // Check filename length
    if (static_cast<size_t>(fileName.size()) >= sizeof(missionMsg.missionIdFileName))
    {
        showDebugMessage("File name too long (max " +
                             QString::number(sizeof(missionMsg.missionIdFileName) - 1) +
                             " bytes)", MsgType::Error);
        QMessageBox::warning(this, "Filename Too Long",
                             QString("File name must be less than %1 bytes.")
                                 .arg(sizeof(missionMsg.missionIdFileName)));
        return;
    }

    // Copy filename into structure
    std::memcpy(missionMsg.missionIdFileName,
                fileName.constData(),
                fileName.size());
    missionMsg.missionIdFileName[fileName.size()] = '\0';

    QByteArray data(reinterpret_cast<const char *>(&missionMsg),
                    sizeof(RawFileMessage));

    qDebug() << "Mission file message is being sent";
    qDebug() << "File Name:" << inputFiles;
    qDebug() << "Data:" << data.toHex(' ').toUpper();
    qDebug() << "Message Size:" << data.size();

    // ---- Show on panel ----
    showDebugMessage("Mission file: " + inputFiles, MsgType::Info);
    showDebugMessage("Mission file message [" + QString::number(data.size()) + " bytes]: " +
                         QString::fromLatin1(data.toHex(' ').toUpper()),
                     MsgType::Sent);

    connection->writeData(data);
}


