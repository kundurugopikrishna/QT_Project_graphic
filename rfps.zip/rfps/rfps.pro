QT += quick sql

SOURCES += \
        databridge.cpp \
        main.cpp

resources.files = main.qml
resources.prefix = /$${TARGET}
RESOURCES += resources
USER_NAME = $$(USER)  # Linux/macOS
DEFINES += USER_NAME=\\\"$$USER_NAME\\\"

# Define bin directory (Cross-Platform)
win32:BIN_DIR = $${PWD}\\bin
unix:BIN_DIR = $${PWD}/bin

# Ensure bin directory exists before building
win32:QMAKE_MKDIR = mkdir
unix:QMAKE_MKDIR = mkdir -p
system($$QMAKE_MKDIR $${BIN_DIR})

# Set target output directory
DESTDIR = $${BIN_DIR}

# Define install path
target.path = $${BIN_DIR}

# Include target in installation
INSTALLS += target

# OS-specific defines
unix:DEFINES += OS_LINUX
win32:DEFINES += OS_WINDOWS

#if OS_WINDOWS then add this lib other wise no
win32:LIBS += -lws2_32

# Build output directories
MOC_DIR = $${OUT_PWD}/build
OBJECTS_DIR = $${OUT_PWD}/build

HEADERS += \
    databridge.h
