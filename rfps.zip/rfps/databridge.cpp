#include "databridge.h"

#include <QCryptographicHash>
#include <QPasswordDigestor>
#include <QRandomGenerator>
#include <QByteArray>
#include <QVariant>
#include <QSqlRecord>
#include <QVariantMap>
#include <QStringList>
// --------------------------------------------------
// Password hashing helper
// --------------------------------------------------
static QByteArray hashPassword(
    const QString &password,
    const QByteArray &salt
    )
{
    return QPasswordDigestor::deriveKeyPbkdf2(
        QCryptographicHash::Sha256,
        password.toUtf8(),
        salt,
        100000,
        32
        );
}
bool DataBridge::updateUser(
    int userId,
    const QString &username,
    const QString &userRole,
    const QString &connectionType)
{
    QSqlDatabase db = QSqlDatabase::database("StationConnection");

    if (!db.isValid() || !db.isOpen())
    {
        setAuthError("Database is not open");
        return false;
    }

    if (username.trimmed().isEmpty())
    {
        setAuthError("Username cannot be empty");
        return false;
    }

    QSqlQuery query(db);

    query.prepare(R"(
        UPDATE Users
        SET username = :username,
            user_role = :userRole,
            connection_type = :connectionType
        WHERE id = :userId
    )");

    query.bindValue(":username", username.trimmed());
    query.bindValue(":userRole", userRole);
    query.bindValue(":connectionType", connectionType);
    query.bindValue(":userId", userId);

    if (!query.exec()) {
        qWarning() << "User update failed:"
                   << query.lastError().text();

        setAuthError(query.lastError().text());
        return false;
    }

    // SQLite may report zero affected rows if the values did not change.
    // Therefore, zero rows does not always mean the user does not exist.
    setAuthError("");
    return true;
}


bool DataBridge::deleteUser(int userId)
{
    QSqlDatabase db = QSqlDatabase::database("StationConnection");

    if (!db.isValid() || !db.isOpen())
    {
        setAuthError("Database is not open");
        return false;
    }

    QSqlQuery query(db);

    query.prepare(
        "DELETE FROM Users WHERE id = :userId"
        );

    query.bindValue(":userId", userId);

    if (!query.exec())
    {
        qWarning() << "User deletion failed:"
                   << query.lastError().text();

        setAuthError(query.lastError().text());
        return false;
    }

    if (query.numRowsAffected() == 0)
    {
        setAuthError("No user was deleted");
        return false;
    }

    setAuthError("");
    return true;
}
// --------------------------------------------------
// Constructor
// --------------------------------------------------
DataBridge::DataBridge(QObject *parent)
    : QObject(parent)
{
    // Existing graph series
    m_seriesNames = {
        "Series 1",
        "Series 2",
        "Series 3",
        "Series 4",
        "Series 5"
    };

    // Existing sample graph data
    m_rawData = {
        QVariantList{12, 25, 18, 35, 28, 45},
        QVariantList{20, 15, 30, 22, 40, 32},
        QVariantList{8, 18, 12, 28, 20, 35},
        QVariantList{15, 22, 10, 30, 25, 40},
        QVariantList{20, 28, 15, 35, 30, 50}
    };

    // Initialize SQLite and create the tables.
    connectDatabase();

    // Keep PostgreSQL disabled unless you need it.
    // loadDataFromPostgres();
}

// --------------------------------------------------
// Set authentication error for QML
// --------------------------------------------------
void DataBridge::setAuthError(const QString &message)
{
    if (m_authError == message)
        return;

    m_authError = message;
    emit authErrorChanged();
}

// --------------------------------------------------
// SQLite connection and table creation
// --------------------------------------------------
// bool DataBridge::connectDatabase()
// {
//     const QString dbPath =
//         QDir(QCoreApplication::applicationDirPath())
//             .filePath("veera.db");

//     QSqlDatabase db;

//     const QString connectionName = "StationConnection";

//     if (QSqlDatabase::contains(connectionName))
//     {
//         db = QSqlDatabase::database(connectionName);
//     }
//     else
//     {
//         db = QSqlDatabase::addDatabase(
//             "QSQLITE",
//             connectionName
//             );

//         db.setDatabaseName(dbPath);
//     }

//     if (!db.isOpen() && !db.open())
//     {
//         qWarning() << "SQLite connection failed:"
//                    << db.lastError().text();

//         return false;
//     }

//     QSqlQuery query(db);

//     // Existing relay configuration table
//     const QString createRelayTable = R"(
//         CREATE TABLE IF NOT EXISTS RelayConfig (
//             id INTEGER PRIMARY KEY AUTOINCREMENT,
//             relay_name TEXT NOT NULL,
//             bit_index INTEGER NOT NULL,
//             state INTEGER NOT NULL DEFAULT 0
//         )
//     )";

//     if (!query.exec(createRelayTable))
//     {
//         qWarning() << "RelayConfig table creation failed:"
//                    << query.lastError().text();

//         return false;
//     }

//     // New user registration table
//     // Passwords are stored as hashes, not plain text.
//     const QString createUsersTable = R"(
//         CREATE TABLE IF NOT EXISTS Users (
//             id INTEGER PRIMARY KEY AUTOINCREMENT,
//             username TEXT NOT NULL COLLATE NOCASE UNIQUE,
//             password_hash BLOB NOT NULL,
//             salt BLOB NOT NULL,
//             created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
//         )
//     )";

//     if (!query.exec(createUsersTable))
//     {
//         qWarning() << "Users table creation failed:"
//                    << query.lastError().text();

//         return false;
//     }

//     qDebug() << "SQLite connected successfully:" << dbPath;
//     qDebug() << "RelayConfig and Users tables are ready.";

//     return true;
// }
    bool DataBridge::connectDatabase()
{
    const QString dbPath =
        QDir(QCoreApplication::applicationDirPath())
            .filePath("veera.db");

    const QString connectionName = "StationConnection";

    QSqlDatabase db;

    if (QSqlDatabase::contains(connectionName)) {
        db = QSqlDatabase::database(connectionName);
    } else {
        db = QSqlDatabase::addDatabase(
            "QSQLITE",
            connectionName
            );

        db.setDatabaseName(dbPath);
    }

    if (!db.isOpen() && !db.open()) {
        qWarning() << "SQLite connection failed:"
                   << db.lastError().text();
        return false;
    }

    QSqlQuery query(db);

    // // Create Users table
    // const QString createUsersTable = R"(
    //     CREATE TABLE IF NOT EXISTS Users (
    //         id INTEGER ,
    //         username INTEGER PRIMARY KEY AUTOINCREMENT,
    //         password TEXT NOT NULL,
    //         user_role TEXT NOT NULL DEFAULT 'Operator',
    //         connection_type TEXT NOT NULL DEFAULT 'Peer',
    //         created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    //     )
    // )";
    const QString createUsersTable = R"(
    CREATE TABLE IF NOT EXISTS Users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL COLLATE NOCASE UNIQUE,
        password TEXT NOT NULL,
        user_role TEXT NOT NULL DEFAULT 'Operator',
        connection_type TEXT NOT NULL DEFAULT 'Peer',
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )
)";

    if (!query.exec(createUsersTable)) {
        qWarning() << "Users table creation failed:"
                   << query.lastError().text();
        return false;
    }

    // Check existing columns and migrate older databases.
    QStringList existingColumns;

    if (!query.exec("PRAGMA table_info(Users)")) {
        qWarning() << "Unable to inspect Users table:"
                   << query.lastError().text();
        return false;
    }

    while (query.next()) {
        existingColumns.append(query.value("name").toString());
    }

    if (!existingColumns.contains("user_role")) {
        if (!query.exec(R"(
            ALTER TABLE Users
            ADD COLUMN user_role TEXT NOT NULL DEFAULT 'Operator'
        )")) {
            qWarning() << "Failed to add user_role:"
                       << query.lastError().text();
            return false;
        }
    }

    if (!existingColumns.contains("connection_type")) {
        if (!query.exec(R"(
            ALTER TABLE Users
            ADD COLUMN connection_type TEXT NOT NULL DEFAULT 'Peer'
        )")) {
            qWarning() << "Failed to add connection_type:"
                       << query.lastError().text();
            return false;
        }
    }

    qDebug() << "SQLite connected successfully:" << dbPath;

    return true;
}

// --------------------------------------------------
// Register a new user
// --------------------------------------------------
// bool DataBridge::registerUser(
//     const QString &username,
//     const QString &password
//     )
// {
//     setAuthError(QString());

//     const QString cleanUsername = username.trimmed();

//     // Validate username
//     if (cleanUsername.length() < 3)
//     {
//         setAuthError(
//             "Username must contain at least 3 characters."
//             );

//         return false;
//     }

//     // Validate password
//     if (password.length() < 8)
//     {
//         setAuthError(
//             "Password must contain at least 8 characters."
//             );

//         return false;
//     }

//     // Ensure SQLite is connected
//     if (!connectDatabase())
//     {
//         setAuthError(
//             "Could not connect to the SQLite database."
//             );

//         return false;
//     }

//     QSqlDatabase db =
//         QSqlDatabase::database("StationConnection");

//     // Generate a random 16-byte salt
//     QByteArray salt(16, Qt::Uninitialized);

//     for (qsizetype i = 0; i < salt.size(); ++i)
//     {
//         salt[i] = static_cast<char>(
//             QRandomGenerator::system()->generate() & 0xFF
//             );
//     }

//     // Hash the password using PBKDF2-HMAC-SHA256
//     const QByteArray passwordHash =
//         hashPassword(password, salt);

//     QSqlQuery query(db);

//     query.prepare(R"(
//         INSERT INTO Users (
//             username,
//             password_hash,
//             salt
//         )
//         VALUES (?, ?, ?)
//     )");

//     query.addBindValue(cleanUsername);
//     query.addBindValue(passwordHash);
//     query.addBindValue(salt);

//     if (!query.exec())
//     {
//         const QString errorText =
//             query.lastError().text();

//         qWarning() << "User registration failed:"
//                    << errorText;

//         if (errorText.contains(
//                 "UNIQUE constraint failed",
//                 Qt::CaseInsensitive))
//         {
//             setAuthError(
//                 "That username already exists. Please choose another."
//                 );
//         }
//         else
//         {
//             setAuthError(
//                 "Registration failed. Please try again."
//                 );
//         }

//         return false;
//     }

//     qDebug() << "User registered successfully:"
//              << cleanUsername;

//     setAuthError("Account created successfully.");

//     return true;
// }
    bool DataBridge::registerUser(
        const QString &username,
        const QString &password,
        const QString &userRole,
        const QString &connectionType)
{
    setAuthError(QString());

    const QString cleanUsername = username.trimmed();

    if (cleanUsername.length() < 3) {
        setAuthError(
            "Username must contain at least 3 characters.");
        return false;
    }

    if (password.length() < 8) {
        setAuthError(
            "Password must contain at least 8 characters.");
        return false;
    }

    const QStringList validRoles = {
        "Admin", "Operator", "Commander"
    };

    const QStringList validConnections = {
        "Peer", "Client", "Server"
    };

    if (!validRoles.contains(userRole)) {
        setAuthError("Please select a valid user role.");
        return false;
    }

    if (!validConnections.contains(connectionType)) {
        setAuthError("Please select a valid connection type.");
        return false;
    }

    if (!connectDatabase()) {
        setAuthError(
            "Could not connect to the SQLite database.");
        return false;
    }

    QSqlDatabase db =
        QSqlDatabase::database("StationConnection");

    QSqlQuery query(db);

    query.prepare(R"(
        INSERT INTO Users (
            username,
            password,
            user_role,
            connection_type
        )
        VALUES (?, ?, ?, ?)
    )");

    query.addBindValue(cleanUsername);
    query.addBindValue(password);
    query.addBindValue(userRole);
    query.addBindValue(connectionType);

    if (!query.exec()) {
        qWarning() << "User registration failed:"
                   << query.lastError().text();

        if (query.lastError().text().contains(
                "UNIQUE constraint failed",
                Qt::CaseInsensitive)) {
            setAuthError(
                "That username already exists.");
        } else {
            setAuthError(
                "Registration failed. Please try again.");
        }

        return false;
    }

    setAuthError("Account created successfully.");

    qDebug() << "User registered:"
             << cleanUsername
             << "Role:" << userRole
             << "Connection:" << connectionType;

    return true;
}


// --------------------------------------------------
// Log in an existing user
// --------------------------------------------------
// bool DataBridge::loginUser(
//     const QString &username,
//     const QString &password
//     )
// {
//     setAuthError(QString());

//     const QString cleanUsername = username.trimmed();

//     if (cleanUsername.isEmpty() || password.isEmpty())
//     {
//         setAuthError(
//             "Please enter your username and password."
//             );

//         return false;
//     }

//     // Ensure SQLite is connected
//     if (!connectDatabase())
//     {
//         setAuthError(
//             "Could not connect to the SQLite database."
//             );

//         return false;
//     }

//     QSqlDatabase db =
//         QSqlDatabase::database("StationConnection");

//     QSqlQuery query(db);

//     query.prepare(R"(
//         SELECT password_hash, salt
//         FROM Users
//         WHERE username = ?
//     )");

//     query.addBindValue(cleanUsername);

//     if (!query.exec())
//     {
//         qWarning() << "Login query failed:"
//                    << query.lastError().text();

//         setAuthError(
//             "Unable to verify login. Please try again."
//             );

//         return false;
//     }

//     if (!query.next())
//     {
//         // Use a generic message to avoid revealing
//         // whether a particular username exists.
//         setAuthError(
//             "Invalid username or password."
//             );

//         return false;
//     }

//     const QByteArray storedHash =
//         query.value("password_hash").toByteArray();

//     const QByteArray storedSalt =
//         query.value("salt").toByteArray();

//     // Hash the entered password using the saved salt
//     const QByteArray enteredHash =
//         hashPassword(password, storedSalt);

//     if (enteredHash != storedHash)
//     {
//         setAuthError(
//             "Invalid username or password."
//             );

//         return false;
//     }

//     qDebug() << "Login successful for user:"
//              << cleanUsername;

//     setAuthError("Login successful.");

//     return true;
// }
    bool DataBridge::loginUser(
        const QString &username,
        const QString &password,
        const QString &userRole,
        const QString &connectionType)
{
    setAuthError(QString());

    const QString cleanUsername = username.trimmed();

    if (cleanUsername.isEmpty() || password.isEmpty()) {
        setAuthError(
            "Please enter your username and password.");
        return false;
    }

    if (!connectDatabase()) {
        setAuthError(
            "Could not connect to the SQLite database.");
        return false;
    }

    QSqlDatabase db =
        QSqlDatabase::database("StationConnection");

    QSqlQuery query(db);

    query.prepare(R"(
        SELECT id
        FROM Users
        WHERE username = ?
          AND password = ?
          AND user_role = ?
          AND connection_type = ?
    )");

    query.addBindValue(cleanUsername);
    query.addBindValue(password);
    query.addBindValue(userRole);
    query.addBindValue(connectionType);

    if (!query.exec()) {
        qWarning() << "Login query failed:"
                   << query.lastError().text();

        setAuthError(
            "Unable to verify login. Please try again.");
        return false;
    }

    if (!query.next()) {
        setAuthError(
            "Invalid credentials, role, or connection type.");
        return false;
    }

    setAuthError("Login successful.");

    qDebug() << "Login successful:"
             << cleanUsername
             << "Role:" << userRole
             << "Connection:" << connectionType;

    return true;
}
\
// --------------------------------------------------
// Existing PostgreSQL loading function
// --------------------------------------------------
void DataBridge::loadDataFromPostgres()
{
    QSqlDatabase db =
        QSqlDatabase::contains("qt_sql_default_connection")
            ? QSqlDatabase::database("qt_sql_default_connection")
            : QSqlDatabase::addDatabase("QPSQL");

    db.setHostName("192.168.1.12");
    db.setPort(5432);
    db.setDatabaseName("NMS_DB");
    db.setUserName("postgres");
    db.setPassword("postgres");

    if (!db.open())
    {
        qWarning() << "PostgreSQL connection failed:"
                   << db.lastError().text();

        return;
    }

    QVariantList updatedRawData;
    QVariantList updatedTableData;

    for (int s = 0; s < 4; ++s)
    {
        QSqlQuery query(db);

        query.prepare(R"(
            SELECT id, series_index, value
            FROM series_data
            WHERE series_index = ?
            ORDER BY id ASC
        )");

        query.addBindValue(s);

        QVariantList seriesValues;

        if (query.exec())
        {
            while (query.next())
            {
                const double val =
                    query.value(2).toDouble();

                seriesValues.append(val);

                QVariantMap row;

                row["id"] = query.value(0).toInt();
                row["series"] =
                    "Series " + QString::number(s + 1);
                row["value"] = val;

                updatedTableData.append(row);
            }
        }
        else
        {
            qWarning() << "PostgreSQL series query failed:"
                       << query.lastError().text();
        }

        if (seriesValues.isEmpty()
            && s < m_rawData.size())
        {
            seriesValues = m_rawData[s].toList();
        }

        updatedRawData.append(seriesValues);
    }

    m_rawData = updatedRawData;
    m_tableData = updatedTableData;

    emit rawDataChanged();
    emit seriesNamesChanged();
    emit tableDataChanged();

    db.close();
}

// --------------------------------------------------
// Existing graph series update function
// --------------------------------------------------
void DataBridge::updateSeriesData(
    int seriesIndex,
    const QVariantList &newData
    )
{
    if (seriesIndex >= 0
        && seriesIndex < m_rawData.size())
    {
        m_rawData[seriesIndex] = newData;

        emit rawDataChanged();
    }
}

// --------------------------------------------------
// Existing graph append function
// --------------------------------------------------
void DataBridge::appendDataPoint(
    int seriesIndex,
    double value
    )
{
    if (seriesIndex >= 0
        && seriesIndex < m_rawData.size())
    {
        QVariantList series =
            m_rawData[seriesIndex].toList();

        series.append(value);

        if (series.size() > 50)
            series.removeFirst();

        m_rawData[seriesIndex] = series;

        emit rawDataChanged();
    }
}
    void DataBridge::loaddatafromsqlite()
{
    if (!connectDatabase()) {
        qWarning() << "SQLite connection failed.";
        return;
    }

    QSqlDatabase db =
        QSqlDatabase::database("StationConnection");

    QSqlQuery query(db);

    query.prepare(R"(
        SELECT id, username, password,
               user_role, connection_type, created_at
        FROM Users
        ORDER BY id
    )");

    if (!query.exec()) {
        qWarning() << "Failed to load users:"
                   << query.lastError().text();
        return;
    }

    QVariantList users;

    while (query.next()) {
        QVariantMap row;

        row["id"] =
            query.value("id").toInt();

        row["username"] =
            query.value("username").toString();

        row["password"] =
            query.value("password").toString();

        row["user_role"] =
            query.value("user_role").toString();

        row["connection_type"] =
            query.value("connection_type").toString();

        row["created_at"] =
            query.value("created_at").toString();

        users.append(row);
    }

    m_tableData = users;

    emit tableDataChanged();

    qDebug() << "Total users loaded:" << users.size();
}
