#pragma once

#include <QObject>
#include <QVariantList>
#include <QStringList>
#include <QTimer>
#include <QString>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QDir>
#include <QDebug>
#include <QCoreApplication>

class DataBridge : public QObject
{
    Q_OBJECT

    Q_PROPERTY(QVariantList rawData READ rawData NOTIFY rawDataChanged)
    Q_PROPERTY(QStringList seriesNames READ seriesNames NOTIFY seriesNamesChanged)
    Q_PROPERTY(QVariantList tableData READ tableData NOTIFY tableDataChanged)

    // Authentication error message exposed to QML
    Q_PROPERTY(QString authError READ authError NOTIFY authErrorChanged)

public:
    explicit DataBridge(QObject *parent = nullptr);

    // Existing graph properties
    QVariantList rawData() const { return m_rawData; }
    QStringList seriesNames() const { return m_seriesNames; }
    QVariantList tableData() const { return m_tableData; }

    // Existing database and graph functions
    bool connectDatabase();

    Q_INVOKABLE void loaddatafromsqlite();
    Q_INVOKABLE void loadDataFromPostgres();
    Q_INVOKABLE void updateSeriesData(
        int seriesIndex,
        const QVariantList &newData
        );
    Q_INVOKABLE void appendDataPoint(
        int seriesIndex,
        double value
        );

    // New registration and login functions
    Q_INVOKABLE bool registerUser(
        const QString &username,
        const QString &password
        );

    Q_INVOKABLE bool loginUser(
        const QString &username,
        const QString &password
        );

    QString authError() const { return m_authError; }

signals:
    void rawDataChanged();
    void seriesNamesChanged();
    void tableDataChanged();

    // Emitted when the authentication error changes
    void authErrorChanged();

private:
    // Existing graph data
    QVariantList m_rawData;
    QStringList m_seriesNames;
    QVariantList m_tableData;

    // Authentication status
    QString m_authError;

    void setAuthError(const QString &message);
};