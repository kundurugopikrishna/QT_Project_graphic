import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs
import QtQuick.Window

ApplicationWindow
{
    id: window
    width: 1200
    height: 800
    minimumWidth: 800
    minimumHeight: 600
    visible: true
    visibility: Window.Maximized

    title: "Raw Data & Waterfall Graph - Responsive"
    color: "#071525"
    property bool authenticated: false
    property bool registerMode: false
    property var seriesNames: (typeof backend !== "undefined" && backend && backend.seriesNames) ? backend.seriesNames : ["Series 1", "Series 2", "Series 3", "Series 4"]
    property var rawData: (typeof backend !== "undefined" && backend && backend.rawData) ? backend.rawData : [[], [], [], []]

    Dialog {
        id: usersDialog

        title: "Registered Users"
        modal: true
        anchors.centerIn: parent

        width: Math.min(window.width * 0.95, 1050)
        height: Math.min(window.height * 0.85, 550)

        background: Rectangle {
            color: "#0A1D31"
            radius: 10
            border.color: "#29445F"
        }

        contentItem: ColumnLayout {
            spacing: 8

            // ---------------- TABLE HEADER ----------------
            RowLayout {
                Layout.fillWidth: true
                spacing: 10

                Label {
                    text: "ID"
                    Layout.preferredWidth: 45
                    color: "#38BDF8"
                    font.bold: true
                }

                Label {
                    text: "Username"
                    Layout.preferredWidth: 130
                    color: "#38BDF8"
                    font.bold: true
                }

                Label {
                    text: "Password"
                    Layout.preferredWidth: 100
                    color: "#38BDF8"
                    font.bold: true
                }

                Label {
                    text: "Created At"
                    Layout.preferredWidth: 160
                    color: "#38BDF8"
                    font.bold: true
                }

                Label {
                    text: "Role"
                    Layout.preferredWidth: 100
                    color: "#38BDF8"
                    font.bold: true
                }

                Label {
                    text: "Connection"
                    Layout.preferredWidth: 110
                    color: "#38BDF8"
                    font.bold: true
                }

                Label {
                    text: "Actions"
                    Layout.preferredWidth: 150
                    color: "#38BDF8"
                    font.bold: true
                }
            }

            Rectangle {
                Layout.fillWidth: true
                height: 1
                color: "#29445F"
            }

            // ---------------- USER LIST ----------------
            ListView {
                id: usersList

                Layout.fillWidth: true
                Layout.fillHeight: true

                clip: true
                spacing: 4

                model: backend.tableData

                delegate: RowLayout {
                    id: userRow

                    required property var modelData

                    width: usersList.width
                    spacing: 10

                    Label {
                        text: String(userRow.modelData.id ?? "")
                        Layout.preferredWidth: 45
                        color: "white"
                    }

                    Label {
                        text: String(userRow.modelData.username ?? "")
                        Layout.preferredWidth: 130
                        color: "white"
                        elide: Text.ElideRight
                    }

                    Label {
                        text: "********"
                        Layout.preferredWidth: 100
                        color: "#94A3B8"
                    }

                    Label {
                        text: String(userRow.modelData.created_at ?? "")
                        Layout.preferredWidth: 160
                        color: "#CBD5E1"
                        elide: Text.ElideRight
                    }

                    Label {
                        text: String(userRow.modelData.user_role ?? "")
                        Layout.preferredWidth: 100
                        color: "white"
                    }

                    Label {
                        text: String(userRow.modelData.connection_type ?? "")
                        Layout.preferredWidth: 110
                        color: "#38BDF8"
                    }

                    // ---------------- ACTION BUTTONS ----------------
                    RowLayout {
                        Layout.preferredWidth: 150
                        spacing: 5

                        Button {
                            text: "Edit"

                            onClicked: {
                                editUserDialog.selectedUser = userRow.modelData

                                editUsernameField.text =
                                        String(userRow.modelData.username ?? "")

                                editRoleCombo.currentIndex =
                                        editRoleCombo.indexOfValue(
                                            String(userRow.modelData.user_role ?? "Operator")
                                        )

                                editConnectionCombo.currentIndex =
                                        editConnectionCombo.indexOfValue(
                                            String(userRow.modelData.connection_type ?? "Client")
                                        )

                                editUserDialog.open()
                            }
                        }

                        Button {
                            text: "Delete"

                            onClicked: {
                                deleteUserDialog.selectedUser = userRow.modelData
                                deleteUserDialog.open()
                            }
                        }
                    }
                }
            }

            // ---------------- FOOTER ----------------
            RowLayout {
                Layout.fillWidth: true

                Label {
                    text: "Total users: " + backend.tableData.length
                    color: "#22C55E"
                    Layout.fillWidth: true
                }

                Button {
                    text: "Refresh"

                    onClicked: {
                        backend.loaddatafromsqlite()
                    }
                }

                Button {
                    text: "Close"

                    onClicked: {
                        usersDialog.close()
                    }
                }
            }
        }
    }
    Dialog {
        id: editUserDialog

        title: "Edit User"
        modal: true
        anchors.centerIn: parent

        width: 380

        property var selectedUser: null

        background: Rectangle {
            color: "#0A1D31"
            radius: 10
            border.color: "#29445F"
        }

        contentItem: ColumnLayout {
            spacing: 12

            Label {
                text: "Username"
                color: "#38BDF8"
            }

            TextField {
                id: editUsernameField

                Layout.fillWidth: true
                placeholderText: "Enter username"
            }

            Label {
                text: "User Role"
                color: "#38BDF8"
            }

            ComboBox {
                id: editRoleCombo

                Layout.fillWidth: true

                textRole: "text"
                valueRole: "value"

                model: [
                    { text: "Admin", value: "Admin" },
                    { text: "Operator", value: "Operator" },
                    { text: "Commander", value: "Commander" }
                ]
            }

            Label {
                text: "Connection Type"
                color: "#38BDF8"
            }

            ComboBox {
                id: editConnectionCombo

                Layout.fillWidth: true

                textRole: "text"
                valueRole: "value"

                model: [
                    { text: "Peer", value: "Peer" },
                    { text: "Client", value: "Client" },
                    { text: "Server", value: "Server" }
                ]
            }

            Label {
                text: "Password remains unchanged."
                color: "#94A3B8"
                font.italic: true
            }

            RowLayout {
                Layout.fillWidth: true

                Item {
                    Layout.fillWidth: true
                }

                Button {
                    text: "Cancel"

                    onClicked: {
                        editUserDialog.close()
                    }
                }

                Button {
                    text: "Save"

                    onClicked: {
                        if (editUserDialog.selectedUser === null)
                            return

                        let userId =
                                Number(editUserDialog.selectedUser.id)

                        let success = backend.updateUser(
                                    userId,
                                    editUsernameField.text,
                                    editRoleCombo.currentValue,
                                    editConnectionCombo.currentValue
                                )

                        if (success) {
                            backend.loaddatafromsqlite()
                            editUserDialog.close()
                        }
                    }
                }
            }
        }
    }
    Dialog {
        id: deleteUserDialog

        title: "Delete User"
        modal: true
        anchors.centerIn: parent

        width: 350

        property var selectedUser: null

        background: Rectangle {
            color: "#0A1D31"
            radius: 10
            border.color: "#EF4444"
        }

        contentItem: ColumnLayout {
            spacing: 12

            Label {
                Layout.fillWidth: true

                text: deleteUserDialog.selectedUser
                      ? "Are you sure you want to delete user \""
                        + String(deleteUserDialog.selectedUser.username)
                        + "\"?"
                      : "Are you sure you want to delete this user?"

                color: "white"
                wrapMode: Text.WordWrap
            }

            RowLayout {
                Layout.fillWidth: true

                Item {
                    Layout.fillWidth: true
                }

                Button {
                    text: "Cancel"

                    onClicked: {
                        deleteUserDialog.close()
                    }
                }

                Button {
                    text: "Delete"
                    palette.button: "#DC2626"

                    onClicked: {
                        if (deleteUserDialog.selectedUser === null)
                            return

                        let userId =
                                Number(deleteUserDialog.selectedUser.id)

                        let success = backend.deleteUser(userId)

                        if (success) {
                            backend.loaddatafromsqlite()
                            deleteUserDialog.close()
                        }
                    }
                }
            }
        }
    }
    Rectangle
    {
        id: authenticationScreen

        anchors.fill: parent
        visible: !window.authenticated
        z: 100

        color: "#071525"

        Rectangle
        {
            id: loginCard

            width: Math.min(parent.width - 40, 420)
            height: window.registerMode ? 510 : 460

            anchors.centerIn: parent

            radius: 16
            color: "#0A1D31"

            border.color: "#29445F"
            border.width: 1

            ColumnLayout
            {
                anchors.fill: parent
                anchors.margins: 30
                spacing: 12

                Label
                {
                    Layout.fillWidth: true
                    text: "RFPS"
                    color: "#38BDF8"
                    font.pixelSize: 30
                    font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                }

                Label
                {
                    Layout.fillWidth: true

                    text: window.registerMode
                          ? "Create Your Account"
                          : "Welcome Back"

                    color: "white"
                    font.pixelSize: 22
                    font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                }

                Label
                {
                    Layout.fillWidth: true
                    text: "Raw Data & Waterfall Visualization"
                    color: "#94A3B8"
                    font.pixelSize: 12
                    horizontalAlignment: Text.AlignHCenter
                    wrapMode: Text.WordWrap
                }

                TextField
                {
                    id: usernameField

                    Layout.fillWidth: true
                    placeholderText: "Enter username"
                    selectByMouse: true
                    color: "white"
                    font.pixelSize: 14

                    background: Rectangle
                    {
                        radius: 6
                        color: "#102A43"
                        border.color: usernameField.activeFocus
                                       ? "#38BDF8" : "#29445F"
                    }
                }

                TextField
                {
                    id: passwordField

                    Layout.fillWidth: true
                    placeholderText: "Enter password"
                    echoMode: TextInput.Password
                    selectByMouse: true
                    color: "white"
                    font.pixelSize: 14

                    background: Rectangle
                    {
                        radius: 6
                        color: "#102A43"
                        border.color: passwordField.activeFocus
                                       ? "#38BDF8" : "#29445F"
                    }

                    onAccepted: authenticationButton.clicked()
                }

                Label
                {
                    text: "User Role"
                    color: "#CBD5E1"
                    font.pixelSize: 12
                }

                ComboBox
                {
                    id: roleComboBox

                    Layout.fillWidth: true

                    model: ["Admin", "Operator", "Commander"]

                    currentIndex: 1

                    contentItem: Text
                    {
                        leftPadding: 10
                        text: roleComboBox.displayText
                        color: "white"
                        verticalAlignment: Text.AlignVCenter
                        elide: Text.ElideRight
                    }

                    background: Rectangle
                    {
                        radius: 6
                        color: "#102A43"
                        border.color: roleComboBox.activeFocus
                                       ? "#38BDF8" : "#29445F"
                    }

                    delegate: ItemDelegate
                    {
                        width: roleComboBox.width

                        contentItem: Text
                        {
                            text: modelData
                            color: "white"
                            verticalAlignment: Text.AlignVCenter
                        }

                        background: Rectangle
                        {
                            color: highlighted ? "#1E3A5F" : "#0A1D31"
                        }
                    }

                    popup.background: Rectangle
                    {
                        color: "#0A1D31"
                        border.color: "#29445F"
                        radius: 6
                    }
                }

                Label
                {
                    text: "Connection Type"
                    color: "#CBD5E1"
                    font.pixelSize: 12
                }

                ComboBox
                {
                    id: connectionComboBox

                    Layout.fillWidth: true

                    model: ["Peer", "Client", "Server"]

                    currentIndex: 0

                    contentItem: Text
                    {
                        leftPadding: 10
                        text: connectionComboBox.displayText
                        color: "white"
                        verticalAlignment: Text.AlignVCenter
                        elide: Text.ElideRight
                    }

                    background: Rectangle
                    {
                        radius: 6
                        color: "#102A43"
                        border.color: connectionComboBox.activeFocus
                                       ? "#38BDF8" : "#29445F"
                    }

                    delegate: ItemDelegate
                    {
                        width: connectionComboBox.width

                        contentItem: Text
                        {
                            text: modelData
                            color: "white"
                            verticalAlignment: Text.AlignVCenter
                        }

                        background: Rectangle
                        {
                            color: highlighted ? "#1E3A5F" : "#0A1D31"
                        }
                    }

                    popup.background: Rectangle
                    {
                        color: "#0A1D31"
                        border.color: "#29445F"
                        radius: 6
                    }
                }

                Label
                {
                    Layout.fillWidth: true
                    visible: window.registerMode

                    text: "Password requirements:\n"
                          + "• At least 8 characters\n"
                          + "• One uppercase letter (A-Z)\n"
                          + "• One lowercase letter (a-z)\n"
                          + "• One number (0-9)\n"
                          + "• One special character"

                    color: "#94A3B8"
                    font.pixelSize: 11
                    wrapMode: Text.WordWrap
                }

                Label
                {
                    Layout.fillWidth: true

                    visible: backend.authError.length > 0
                    text: backend.authError

                    color: backend.authError === "Login successful."
                           || backend.authError === "Account created successfully."
                           ? "#22C55E" : "#F87171"

                    font.pixelSize: 12
                    wrapMode: Text.WordWrap
                    horizontalAlignment: Text.AlignHCenter
                }

                Button
                {
                    id: authenticationButton

                    Layout.fillWidth: true
                    Layout.preferredHeight: 44

                    text: window.registerMode
                          ? "Create Account" : "Login"

                    onClicked:
                    {
                        if (typeof backend === "undefined" || !backend)
                            return

                        if (window.registerMode)
                        {
                            if (backend.registerUser(
                                        usernameField.text,
                                        passwordField.text,
                                        roleComboBox.currentText,
                                        connectionComboBox.currentText))
                            {

                                window.authenticated = true
                                passwordField.clear()
                            }
                        }
                        else
                        {
                            if (backend.loginUser(
                                        usernameField.text,
                                        passwordField.text,
                                        roleComboBox.currentText,
                                        connectionComboBox.currentText))
                            {

                                window.authenticated = true
                                passwordField.clear()
                            }
                        }
                    }
                    background: Rectangle
                    {
                        radius: 6
                        color: authenticationButton.down
                               ? "#0284C7" : "#38BDF8"
                    }

                    contentItem: Text
                    {
                        text: authenticationButton.text
                        color: "#071525"
                        font.pixelSize: 15
                        font.bold: true
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                }

                Button
                {
                    Layout.fillWidth: true
                    flat: true

                    text: window.registerMode
                          ? "Already have an account? Login"
                          : "New user? Create an account"

                    onClicked:
                    {
                        window.registerMode = !window.registerMode
                        usernameField.clear()
                        passwordField.clear()
                    }

                    contentItem: Text
                    {
                        text: parent.text
                        color: "#38BDF8"
                        font.pixelSize: 12
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                        wrapMode: Text.WordWrap
                    }

                    background: Rectangle
                    {
                        color: "transparent"
                    }
                }
            }
        }
    }
    Connections
    {
        target: typeof backend !== "undefined" ? backend : null
        function onRawDataChanged()
        {
            if (backend)
            {
                window.rawData = backend.rawData
                rawGraph.requestPaint()
            }
        }
        function onSeriesNamesChanged()
        {
            if (backend)
            {
                window.seriesNames = backend.seriesNames
                rawGraph.requestPaint()
            }
        }
    }
    Timer
    {
        interval: 500
        repeat: true
        running: window.liveEnabled
        onTriggered:
        {
            if (typeof backend !== "undefined" && backend)
            {
                let val = Math.random() * 100
                backend.appendDataPoint(0, val)
            }
        }
    }

    property real scaleFactor: Math.min(width / 1200, height / 800)
    property real dynamicFontSize: Math.max(10, 12 * scaleFactor)
    property real dynamicTitleSize: Math.max(18, 24 * scaleFactor)

    property var seriesColors:
    [
        "#38BDF8",
        "#22C55E",
        "#F59E0B",
        "#F472B6"
    ]

    property color increaseColor: "#22C55E"
    property color decreaseColor: "#F87171"
    property color totalColor: "#38BDF8"
    property int selectedSeries: 0

    function setSeriesCount(count)
    {
        let targetCount = Math.max(1, Math.min(8, count))
        let names = []
        let colors = []
        let data = []
        let defaultPalette = ["#38BDF8", "#22C55E", "#F59E0B", "#F472B6", "#A855F7", "#EC4899", "#14B8A6", "#EAB308"]

        for (let i = 0; i < targetCount; i++)
        {
            names.push(i < window.seriesNames.length ? window.seriesNames[i] : ("Series " + (i + 1)))
            colors.push(i < window.seriesColors.length ? window.seriesColors[i] : defaultPalette[i % defaultPalette.length])
            data.push(i < window.rawData.length ? window.rawData[i] : new Array(50).fill(50))
        }

        window.seriesNames = names
        window.seriesColors = colors
        window.rawData = data
        rawGraph.requestPaint()
    }

    ColorDialog
    {
        id: colorDialog
        title: "Select Graph Color"

        onAccepted:
        {
            if (window.selectedSeries >= 0)
            {
                let updatedColors = window.seriesColors.slice()
                updatedColors[window.selectedSeries] = selectedColor.toString()
                window.seriesColors = updatedColors
                rawGraph.requestPaint()
            } else if (window.selectedSeries === -1)
            {
                window.increaseColor = selectedColor
                waterfallGraph.requestPaint()
            } else if (window.selectedSeries === -2)
            {
                window.decreaseColor = selectedColor
                waterfallGraph.requestPaint()
            } else if (window.selectedSeries === -3)
            {
                window.totalColor = selectedColor
                waterfallGraph.requestPaint()
            }
        }
    }

    property var waterfallData:
    [
        { label: "Start", value: 100, type: "total" },
        { label: "Input", value: 35, type: "change" },
        { label: "Loss", value: -20, type: "change" },
        { label: "Gain", value: 45, type: "change" },
        { label: "Drop", value: -30, type: "change" },
        { label: "Output", value: 130, type: "total" }
    ]

    property bool liveEnabled: false

    function addRawData()
    {
        let updated = []
        for (let s = 0; s < rawData.length; s++)
        {
            let values = rawData[s].slice()
            let previous = values.length > 0 ? values[values.length - 1] : 50
            let next = previous + (Math.random() - 0.5) * 20
            next = Math.max(0, Math.min(100, next))
            values.push(next)
            if (values.length > 50) values.shift()
            updated.push(values)
        }
        rawData = updated
        rawGraph.requestPaint()
    }

    function clearRawData()
    {
        let emptyData = []
        for (let i = 0; i < window.seriesNames.length; i++)
        {
            emptyData.push([])
        }
        rawData = emptyData
        rawGraph.requestPaint()
    }

    function clearWaterfall()
    {
        waterfallData = []
        waterfallGraph.requestPaint()
    }

    function addWaterfallValue(value)
    {
        let updated = waterfallData.slice()
        updated.push(
        {
            label: "Step " + updated.length,
            value: value,
            type: "change"
        })
        waterfallData = updated
        waterfallGraph.requestPaint()
    }

    ColumnLayout
    {
        anchors.fill: parent
        anchors.margins: Math.max(10, 18 * window.scaleFactor)
        spacing: Math.max(8, 14 * window.scaleFactor)

        RowLayout
        {
            Layout.fillWidth: true
            spacing: Math.max(6, 12 * window.scaleFactor)

            ColumnLayout
            {
                spacing: 2
                Label
                {
                    text: "DATA VISUALIZATION"
                    color: "#38BDF8"
                    font.pixelSize: Math.max(10, 12 * window.scaleFactor)
                    font.bold: true
                }
                Label
                {
                    text: "Raw Data & Waterfall"
                    color: "white"
                    font.pixelSize: window.dynamicTitleSize
                    font.bold: true
                }
            }

            RowLayout
            {
                spacing: 6
                Label
                {
                    text: "Series Count:"
                    color: "#CBD5E1"
                    font.pixelSize: window.dynamicFontSize
                }
                TextField
                {
                    id: seriesTextField
                    text: window.seriesNames.length.toString()
                    color: "black"
                    font.pixelSize: window.dynamicFontSize
                    implicitWidth: 50
                    validator: IntValidator { bottom: 1; top: 8 }

                    onAccepted:
                    {
                        let val = parseInt(text)
                        if (!isNaN(val)) window.setSeriesCount(val)
                    }
                    onEditingFinished:
                    {
                        let val = parseInt(text)
                        if (!isNaN(val)) window.setSeriesCount(val)
                        else text = window.seriesNames.length.toString()
                    }
                }
            }

            RowLayout
            {
                spacing: Math.max(4, 6 * window.scaleFactor)
                Repeater
                {
                    model: window.seriesNames
                    delegate: Button
                    {
                        required property int index
                        required property string modelData
                        text: modelData
                        background: Rectangle
                        {
                            radius: 5
                            color: window.seriesColors[index] || "#38BDF8"
                        }
                        contentItem: Text
                        {
                            text: parent.text
                            color: "#071525"
                            font.bold: true
                            font.pixelSize: window.dynamicFontSize
                            horizontalAlignment: Text.AlignHCenter
                            verticalAlignment: Text.AlignVCenter
                        }
                        onClicked:
                        {
                            window.selectedSeries = index
                            colorDialog.selectedColor = window.seriesColors[index] || "#38BDF8"
                            colorDialog.open()
                        }
                    }
                }
            }

            // Waterfall Theme Color Buttons
            RowLayout
            {
                spacing: Math.max(4, 6 * window.scaleFactor)
                Button
                {
                    text: "Inc Color"
                    onClicked:
                    {
                        window.selectedSeries = -1
                        colorDialog.selectedColor = window.increaseColor
                        colorDialog.open()
                    }
                }
                Button
                {
                    text: "Dec Color"
                    onClicked:
                    {
                        window.selectedSeries = -2
                        colorDialog.selectedColor = window.decreaseColor
                        colorDialog.open()
                    }
                }
                Button
                {
                    text: "Tot Color"
                    onClicked:
                    {
                        window.selectedSeries = -3
                        colorDialog.selectedColor = window.totalColor
                        colorDialog.open()
                    }
                }
            }

            Item { Layout.fillWidth: true }

            // NEW: Load DB schema / data button from QML
            Button
            {
                text: "Load DB"
                onClicked: {
                    backend.loaddatafromsqlite()
                    usersDialog.open()
                }
            }

            Button
            {
                text: window.liveEnabled ? "Stop Live" : "Start Live"
                onClicked: window.liveEnabled = !window.liveEnabled
            }
            Button
            {
                text: "Add Data"
                onClicked: window.addRawData()
            }
            Button
            {
                text: "Clear"
                onClicked: window.clearRawData()
            }
        }

        // RAW DATA GRAPH CONTAINER
        Rectangle
        {
            Layout.fillWidth: true
            Layout.fillHeight: true
            Layout.minimumHeight: 220
            color: "#0A1D31"
            radius: 12
            border.color: "#29445F"

            ColumnLayout
            {
                anchors.fill: parent
                anchors.margins: Math.max(8, 14 * window.scaleFactor)
                spacing: 8

                RowLayout
                {
                    Layout.fillWidth: true
                    Label
                    {
                        text: "Raw Data Graph"
                        color: "white"
                        font.pixelSize: Math.max(14, 17 * window.scaleFactor)
                        font.bold: true
                    }
                    Item { Layout.fillWidth: true }
                }

                Canvas
                {
                    id: rawGraph
                    Layout.fillWidth: true
                    Layout.fillHeight: true

                    onWidthChanged: requestPaint()
                    onHeightChanged: requestPaint()

                    onPaint:
                    {
                        let ctx = getContext("2d")
                        ctx.clearRect(0, 0, width, height)

                        let left = Math.max(35, 45 * window.scaleFactor)
                        let right = 15
                        let top = 15
                        let bottom = Math.max(25, 30 * window.scaleFactor)

                        let graphWidth = width - left - right
                        let graphHeight = height - top - bottom

                        if (graphWidth <= 0 || graphHeight <= 0) return

                        // GRID
                        ctx.font = Math.max(9, Math.floor(11 * window.scaleFactor)) + "px sans-serif"
                        ctx.textAlign = "right"
                        ctx.textBaseline = "middle"

                        for (let i = 0; i <= 5; i++)
                        {
                            let y = top + graphHeight * i / 5
                            let value = 100 - i * 20

                            ctx.beginPath()
                            ctx.moveTo(left, y)
                            ctx.lineTo(left + graphWidth, y)
                            ctx.strokeStyle = "#243B53"
                            ctx.lineWidth = 1
                            ctx.stroke()

                            ctx.fillStyle = "#94A3B8"
                            ctx.fillText(value, left - 8, y)
                        }

                        // AXES
                        ctx.beginPath()
                        ctx.moveTo(left, top)
                        ctx.lineTo(left, top + graphHeight)
                        ctx.lineTo(left + graphWidth, top + graphHeight)
                        ctx.strokeStyle = "#64748B"
                        ctx.lineWidth = 1
                        ctx.stroke()

                        // DATA SERIES
                        for (let s = 0; s < window.rawData.length; s++)
                        {
                            let values = window.rawData[s]
                            if (!values || values.length < 1) continue

                            ctx.beginPath()
                            ctx.strokeStyle = window.seriesColors[s] || "#38BDF8"
                            ctx.lineWidth = 2

                            for (let i = 0; i < values.length; i++)
                            {
                                let x = left + (values.length === 1 ? graphWidth / 2 : i * graphWidth / (values.length - 1))
                                let y = top + graphHeight - (values[i] / 100) * graphHeight

                                if (i === 0) ctx.moveTo(x, y)
                                else ctx.lineTo(x, y)
                            }
                            ctx.stroke()
                        }

                        // X AXIS LABELS
                        ctx.fillStyle = "#94A3B8"
                        ctx.textAlign = "center"
                        ctx.textBaseline = "top"
                        ctx.fillText("Oldest", left, top + graphHeight + 8)
                        ctx.fillText("Latest", left + graphWidth, top + graphHeight + 8)
                    }
                }
            }
        }

        Rectangle
        {
            Layout.fillWidth: true
            Layout.fillHeight: true
            Layout.minimumHeight: 250
            color: "#0A1D31"
            radius: 12
            border.color: "#29445F"

            ColumnLayout
            {
                anchors.fill: parent
                anchors.margins: Math.max(8, 14 * window.scaleFactor)
                spacing: 8

                RowLayout
                {
                    Layout.fillWidth: true
                    Label
                    {
                        text: "2D Waterfall Chart"
                        color: "white"
                        font.pixelSize: Math.max(14, 17 * window.scaleFactor)
                        font.bold: true
                    }

                    Item { Layout.fillWidth: true }

                    Button
                    {
                        text: "+ Increase"
                        onClicked: window.addWaterfallValue(10)
                    }
                    Button
                    {
                        text: "- Decrease"
                        onClicked: window.addWaterfallValue(-10)
                    }
                    Button
                    {
                        text: "Clear"
                        onClicked: window.clearWaterfall()
                    }
                }

                Canvas
                {
                    id: waterfallGraph
                    Layout.fillWidth: true
                    Layout.fillHeight: true

                    onWidthChanged: requestPaint()
                    onHeightChanged: requestPaint()

                    onPaint:
                    {
                        let ctx = getContext("2d")
                        ctx.clearRect(0, 0, width, height)

                        let left = Math.max(40, 50 * window.scaleFactor)
                        let right = 15
                        let top = 15
                        let bottom = Math.max(35, 45 * window.scaleFactor)

                        let graphWidth = width - left - right
                        let graphHeight = height - top - bottom
                        let data = window.waterfallData

                        if (data.length === 0 || graphWidth <= 0 || graphHeight <= 0) return

                        let levels = []
                        let cumulative = 0
                        let minValue = 0, maxValue = 0

                        for (let i = 0; i < data.length; i++)
                        {
                            let start, end
                            if (data[i].type === "total")
                            {
                                start = 0
                                end = data[i].value
                                cumulative = data[i].value
                            }
                            else
                            {
                                start = cumulative
                                end = cumulative + data[i].value
                                cumulative = end
                            }
                            levels.push({ start: start, end: end })
                            minValue = Math.min(minValue, start, end)
                            maxValue = Math.max(maxValue, start, end)
                        }

                        if (minValue === maxValue) maxValue += 10
                        let padding = (maxValue - minValue) * 0.1
                        minValue -= padding
                        maxValue += padding

                        function valueToY(value)
                        {
                            return top + graphHeight - ((value - minValue) / (maxValue - minValue)) * graphHeight
                        }

                        // HORIZONTAL GRID
                        ctx.font = Math.max(9, Math.floor(11 * window.scaleFactor)) + "px sans-serif"
                        ctx.textAlign = "right"
                        ctx.textBaseline = "middle"

                        for (let i = 0; i <= 5; i++)
                        {
                            let value = minValue + (maxValue - minValue) * i / 5
                            let y = valueToY(value)

                            ctx.beginPath()
                            ctx.moveTo(left, y)
                            ctx.lineTo(left + graphWidth, y)
                            ctx.strokeStyle = "#243B53"
                            ctx.lineWidth = 1
                            ctx.stroke()

                            ctx.fillStyle = "#94A3B8"
                            ctx.fillText(value.toFixed(0), left - 8, y)
                        }

                        // BARS
                        let slotWidth = graphWidth / data.length
                        let barWidth = Math.min(60, slotWidth * 0.65)

                        for (let i = 0; i < data.length; i++)
                        {
                            let item = data[i]
                            let level = levels[i]
                            let x = left + i * slotWidth + (slotWidth - barWidth) / 2
                            let y1 = valueToY(level.start)
                            let y2 = valueToY(level.end)
                            let y = Math.min(y1, y2)
                            let barHeight = Math.max(2, Math.abs(y2 - y1))

                            if (item.type === "total")
                            {
                                ctx.fillStyle = window.totalColor ? window.totalColor.toString() : "#38BDF8"
                            }
                            else if (item.value >= 0)
                            {
                                ctx.fillStyle = window.increaseColor ? window.increaseColor.toString() : "#22C55E"
                            }
                            else
                            {
                                ctx.fillStyle = window.decreaseColor ? window.decreaseColor.toString() : "#F87171"
                            }

                            ctx.fillRect(x, y, barWidth, barHeight)
                            ctx.strokeStyle = "#CBD5E1"
                            ctx.lineWidth = 0.7
                            ctx.strokeRect(x, y, barWidth, barHeight)

                            // VALUE LABEL
                            ctx.fillStyle = "#FFFFFF"
                            ctx.font = Math.max(9, Math.floor(11 * window.scaleFactor)) + "px sans-serif"
                            ctx.textAlign = "center"
                            ctx.textBaseline = "bottom"
                            ctx.fillText(item.value.toFixed(0), x + barWidth / 2, y - 3)

                            // CATEGORY LABEL
                            ctx.save()
                            ctx.translate(x + barWidth / 2, top + graphHeight + 10)
                            ctx.rotate(-Math.PI / 5)
                            ctx.textAlign = "right"
                            ctx.textBaseline = "middle"
                            ctx.fillStyle = "#CBD5E1"
                            ctx.font = Math.max(9, Math.floor(11 * window.scaleFactor)) + "px sans-serif"
                            ctx.fillText(item.label, 0, 0)
                            ctx.restore()
                        }

                        // AXES
                        ctx.beginPath()
                        ctx.moveTo(left, top)
                        ctx.lineTo(left, top + graphHeight)
                        ctx.lineTo(left + graphWidth, top + graphHeight)
                        ctx.strokeStyle = "#64748B"
                        ctx.stroke()
                    }
                }
            }
        }
    }
}