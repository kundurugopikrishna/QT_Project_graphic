#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include "databridge.h"
int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;
    DataBridge dataBridge;
    engine.rootContext()->setContextProperty("backend", &dataBridge);

    const QUrl url(QStringLiteral("qrc:/rfps/main.qml"));
    QObject::connect(
        &engine,
        &QQmlApplicationEngine::objectCreated,
        &app,
        [url](QObject *obj, const QUrl &objUrl) {
            if (!obj && url == objUrl)
                QCoreApplication::exit(-1);
        },
        Qt::QueuedConnection);
    engine.load(url);

    return QGuiApplication::exec();
}
